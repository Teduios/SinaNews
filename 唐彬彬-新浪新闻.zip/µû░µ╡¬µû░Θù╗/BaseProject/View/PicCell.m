//
//  PicCell.m
//  BaseProject
//
//  Created by apple-jd18 on 15/11/11.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "PicCell.h"

@implementation PicCell
-(UILabel *)introLb{
    if (!_introLb) {
        _introLb = [[UILabel alloc]init ];
        _introLb.font = [UIFont systemFontOfSize:14];
        _introLb.numberOfLines = 0;
        _introLb.textColor = [UIColor lightGrayColor];
        [self.contentView addSubview:_introLb];
        
        [self.introLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(3);
            make.bottom.mas_equalTo(-3);
            make.right.mas_equalTo(-3);
//            make.height.mas_lessThanOrEqualTo(50);
//            make.height.mas_lessThanOrEqualTo(25);
           
            make.height.mas_equalTo(45);
            
        }];
    }
    return _introLb;
}
-(UILabel *)commentLb{
    if (!_commentLb) {
        _commentLb = [[UILabel alloc]init ];
        _commentLb.textColor = [UIColor lightGrayColor];
        _commentLb.font = [UIFont systemFontOfSize:12];
        [self.contentView addSubview:_commentLb];
        [self.commentLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.mas_equalTo(-3);
            make.bottom.mas_equalTo(self.introLb.mas_top).mas_equalTo(-10);
            make.size.mas_equalTo(CGSizeMake(60, 10));
        }];
    }
    return _commentLb;
}

-(UILabel *)titleLb{
    if (!_titleLb) {
        _titleLb = [[UILabel alloc]init ];
        _titleLb.font = [UIFont systemFontOfSize:15];
        [self.contentView addSubview:_titleLb];
        [self.titleLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(3);
            make.bottom.mas_equalTo(self.introLb.mas_top).mas_equalTo(-3);
            
            make.height.mas_equalTo(20);
            make.right.mas_equalTo(self.commentLb.mas_left).mas_equalTo(-4);
        }];
    }
    return _titleLb;
}

-(TRImageView *)iconIVP{
    if (!_iconIVP) {
        _iconIVP = [[TRImageView alloc]init ];

        [self.contentView addSubview:_iconIVP];
        [self.iconIVP mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(0);
            make.top.mas_equalTo(3);
            make.right.mas_equalTo(0);
//            make.bottomMargin.mas_equalTo(_titleLb.mas_topMargin).mas_equalTo(4);
            make.height.mas_equalTo(202);
        }];
    }
    return _iconIVP;
}

-(id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self=[super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        
    }
    return self;
}

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
