//
//  WeahterCell.h
//  新浪新闻
//
//  Created by apple-jd18 on 15/11/27.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WeahterCell : UITableViewCell
//温度区间
@property (weak, nonatomic) IBOutlet UILabel *FtemperatureLB;
//图标
@property (weak, nonatomic) IBOutlet UIImageView *FImage;
//度
@property (weak, nonatomic) IBOutlet UILabel *tempLB;
//风
@property (weak, nonatomic) IBOutlet UILabel *FwindLB;
//周
@property (weak, nonatomic) IBOutlet UILabel *FWeekLb;
@property (weak, nonatomic) IBOutlet UIView *banrkView;

@end
