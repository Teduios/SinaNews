//
//  TopicCell.h
//  新浪新闻
//
//  Created by apple-jd18 on 15/11/18.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TRImageView.h"
@interface TopicCell : UITableViewCell
//**标题标签*/
@property(nonatomic,strong)UILabel *titleLb;
//**详情标签*/
@property(nonatomic,strong)UILabel *introLb;
//评论标签/
@property(nonatomic,strong)UILabel *commentLb;
//**图片*/
@property(nonatomic,strong)TRImageView *iconIVT;



@end
