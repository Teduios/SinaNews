//
//  TopicVCell.m
//  新浪新闻
//
//  Created by apple-jd18 on 15/11/22.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "TopicVCell.h"

@implementation TopicVCell
-(TRImageView *)iconIV{
    if (!_iconIV) {
        _iconIV = [[TRImageView alloc]init ];
        [self.contentView addSubview:_iconIV];
        [self.iconIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(3);
            make.top.mas_equalTo(4);
            make.size.mas_equalTo(CGSizeMake(85, 65));
            
        }];
    }
    return _iconIV;
}

-(UILabel *)titleLbV{
    if (!_titleLbV) {
        _titleLbV = [[UILabel alloc]init ];
        _introLbV.font  = [UIFont systemFontOfSize:15];
        [self.contentView addSubview:_titleLbV];
        [self.titleLbV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(self.iconIV.mas_right).mas_equalTo(3);
            make.top.mas_equalTo(4);
            make.right.mas_equalTo(-3);
            make.height.mas_equalTo(20);
        }];
    }
    return _titleLbV;
}
-(UILabel *)introLbV{
    if (!_introLbV) {
        _introLbV = [[UILabel alloc]init ];
        _introLbV.font  = [UIFont systemFontOfSize:13];
        _introLbV.textColor = [UIColor lightGrayColor];
        _introLbV.numberOfLines = 0;
        [self.contentView addSubview:_introLbV];
        [self.introLbV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(self.iconIV.mas_right).mas_equalTo(3);
            make.top.mas_equalTo(self.titleLbV.mas_bottom).mas_equalTo(2);
            make.right.mas_equalTo(-3);
//            make.bottom.mas_equalTo(self.commentLbV.mas_top).mas_equalTo(-2);
            make.height.mas_equalTo(45);
        }];
    }
    return _introLbV;
}

-(TRImageView *)ivtit{
    if (!_ivtit) {
        _ivtit = [[TRImageView alloc]init ];
        
        [self.contentView addSubview:_ivtit];
        
        [self.ivtit mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.mas_equalTo(self.commentLbV.mas_left).mas_equalTo(-5);
//            make.bottom.mas_equalTo(-2);巴黎巴黎
            make.top.mas_equalTo(self.introLbV.mas_bottom).mas_equalTo(4);
            make.size.mas_equalTo(CGSizeMake(10, 10));
        }];
    
    }
    return _ivtit;
}

-(UILabel *)commentLbV{
    if (!_commentLbV) {
        _commentLbV = [[UILabel alloc]init ];
        _commentLbV.font = [UIFont systemFontOfSize:11];
        _commentLbV.textColor = [UIColor lightGrayColor];
        [self.contentView addSubview:_commentLbV];
        [self.commentLbV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.mas_equalTo(-3);
//            make.bottom.mas_equalTo(-8);
            make.top.mas_equalTo(self.introLbV.mas_bottom).mas_equalTo(3);
            make.size.mas_equalTo(CGSizeMake(75, 10));
            
        }];
        
    }
    return _commentLbV;
}
-(id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self=[super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        
    }
    return self;
}
- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
