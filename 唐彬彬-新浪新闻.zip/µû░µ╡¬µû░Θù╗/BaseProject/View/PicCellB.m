//
//  PicCellB.m
//  BaseProject
//
//  Created by apple-jd18 on 15/11/11.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "PicCellB.h"

@implementation PicCellB
-(UILabel *)introLbB{
    if (!_introLbB) {
        _introLbB = [[UILabel alloc]init ];
        _introLbB.font = [UIFont systemFontOfSize:14];
        _introLbB.textColor = [UIColor lightGrayColor];
        _introLbB.numberOfLines = 0;
        [self.contentView addSubview:_introLbB];
        [self.introLbB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(3);
            make.bottom.mas_equalTo(-3);
            make.right.mas_equalTo(-3);
//            make.height.mas_lessThanOrEqualTo(50);
//            make.height.mas_lessThanOrEqualTo(25);
            make.height.mas_equalTo(45);
        }];
    }
    return _introLbB;
}
-(UILabel *)commentLbB{
    if (!_commentLbB) {
        _commentLbB = [[UILabel alloc]init ];
        _commentLbB.textColor = [UIColor lightGrayColor];
        _commentLbB.font = [UIFont systemFontOfSize:12];
        [self.contentView addSubview:_commentLbB];
        [self.commentLbB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.mas_equalTo(-3);
            make.bottom.mas_equalTo(self.introLbB.mas_top).mas_equalTo(-10);
            make.size.mas_equalTo(CGSizeMake(60, 10));
        }];
    }
    return _commentLbB;
}

-(UILabel *)titleLbB{
    if (!_titleLbB) {
        _titleLbB = [[UILabel alloc]init ];
        _titleLbB.font = [UIFont systemFontOfSize:15];
        [self.contentView addSubview:_titleLbB];
        [self.titleLbB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(3);
            make.bottom.mas_equalTo(self.introLbB.mas_top).mas_equalTo(-3);
            make.height.mas_equalTo(20);
            make.right.mas_equalTo(self.commentLbB.mas_left).mas_equalTo(-4);
        }];
    }
    return _titleLbB;
}

-(TRImageView *)iconIVB1{
    if (!_iconIVB1) {
        _iconIVB1 = [[TRImageView alloc]init ];
        [self.contentView addSubview:_iconIVB1];
        [self.iconIVB1 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(0);
//            make.right.mas_equalTo(0);
            make.top.mas_equalTo(3);
            make.size.mas_equalTo(CGSizeMake(kWindowW, 130));
        }];
    }
    return _iconIVB1;
}
-(TRImageView *)iconIVB2{
    if (!_iconIVB2) {
        _iconIVB2 = [[TRImageView alloc]init ];
        [self.contentView addSubview:_iconIVB2];
        [self.iconIVB2 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(0);
            make.top.mas_equalTo(self.iconIVB1.mas_bottom).mas_equalTo(2);
            make.size.mas_equalTo(CGSizeMake(kWindowW/2-1, 70));
        }];
 
    }
    return _iconIVB2;
}
-(TRImageView *)iconIVB3{
    if (!_iconIVB3) {
        _iconIVB3 = [[TRImageView alloc]init ];
        [self.contentView addSubview:_iconIVB3];
        [self.iconIVB3 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.mas_equalTo(0);
            
            make.top.mas_equalTo(self.iconIVB1.mas_bottom).mas_equalTo(2);
            
            make.size.mas_equalTo(CGSizeMake(kWindowW/2-1, 70));

        }];
    }
    return _iconIVB3;
}

-(id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self=[super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        
    }
    return self;
}
- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
