//
//  TopicVCell.h
//  新浪新闻
//
//  Created by apple-jd18 on 15/11/22.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TRImageView.h"
@interface TopicVCell : UITableViewCell
//**标题标签*/
@property(nonatomic,strong)UILabel *titleLbV;
//**详情标签*/
@property(nonatomic,strong)UILabel *introLbV;
//评论标签/
@property(nonatomic,strong)UILabel *commentLbV;
//**图片*/
@property(nonatomic,strong)TRImageView *iconIV;

@property(nonatomic,strong)TRImageView *ivtit;
@end
