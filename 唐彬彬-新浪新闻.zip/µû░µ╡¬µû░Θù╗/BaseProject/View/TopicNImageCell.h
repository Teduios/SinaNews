//
//  TopicNImageCell.h
//  新浪新闻
//
//  Created by apple-jd18 on 15/11/22.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TopicNImageCell : UITableViewCell
@property(nonatomic,strong)UILabel *titleLbN;
//**详情标签*/
@property(nonatomic,strong)UILabel *introLbN;
//评论标签/
@property(nonatomic,strong)UILabel *commentLbN;
@end
