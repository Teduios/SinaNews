//
//  PicCellC.m
//  BaseProject
//
//  Created by apple-jd18 on 15/11/11.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "PicCellC.h"

@implementation PicCellC
-(UILabel *)introLbC{
    if (!_introLbC) {
        _introLbC = [[UILabel alloc]init ];
        _introLbC.font = [UIFont systemFontOfSize:14];
        _introLbC.numberOfLines = 0;
        _introLbC.textColor = [UIColor lightGrayColor];
        [self.contentView addSubview:_introLbC];
        [self.introLbC mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(3);
            make.bottom.mas_equalTo(-3);
            make.right.mas_equalTo(-3);
//            make.height.mas_lessThanOrEqualTo(50);
//            make.height.mas_lessThanOrEqualTo(25);
            make.height.mas_equalTo(45);
        }];
    }
    return _introLbC;
}
-(UILabel *)commentLbC{
    if (!_commentLbC) {
        _commentLbC = [[UILabel alloc]init ];
        _commentLbC.textColor = [UIColor lightGrayColor];
        _commentLbC.font = [UIFont systemFontOfSize:12];
        [self.contentView addSubview:_commentLbC];
        [self.commentLbC mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.mas_equalTo(-3);
            make.bottom.mas_equalTo(self.introLbC.mas_top).mas_equalTo(-10);
            make.size.mas_equalTo(CGSizeMake(60, 10));
        }];
    }
    return _commentLbC;
}

-(UILabel *)titleLbC{
    if (!_titleLbC) {
        _titleLbC = [[UILabel alloc]init ];
        _titleLbC.font = [UIFont systemFontOfSize:15];
        [self.contentView addSubview:_titleLbC];
        [self.titleLbC mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(3);
            make.bottom.mas_equalTo(self.introLbC.mas_top).mas_equalTo(-3);
            make.height.mas_equalTo(20);
            make.right.mas_equalTo(self.commentLbC.mas_left).mas_equalTo(-4);
        }];
    }
    return _titleLbC;
}

-(TRImageView *)iconIVC1{
    if (!_iconIVC1) {
        _iconIVC1 = [[TRImageView alloc]init ];
        
        [self.contentView addSubview:_iconIVC1];
        [self.iconIVC1 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(0);
            make.top.mas_equalTo(3);
            make.size.mas_equalTo(CGSizeMake(kWindowW/2-1, 202));
        }];
    }
    return _iconIVC1;
}
-(TRImageView *)iconIVC2{
    if (!_iconIVC2) {
        
    
    _iconIVC2 = [[TRImageView alloc]init ];
    [self.contentView addSubview:_iconIVC2];
    [self.iconIVC2 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_equalTo(0);
        make.top.mas_equalTo(3);
        make.size.mas_equalTo(CGSizeMake(kWindowW/2-1, 100));
        
    }];
    }
    return _iconIVC2;
}
-(TRImageView *)iconIVC3{
    if (!_iconIVC3) {
        _iconIVC3 = [[TRImageView alloc]init ];
        [self.contentView addSubview:_iconIVC3];
        [self.iconIVC3 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.mas_equalTo(0);
            make.top.mas_equalTo(self.iconIVC2.mas_bottom).mas_equalTo(2);
            make.size.mas_equalTo(self.iconIVC2);
        }];
    }
    return _iconIVC3;
}

-(id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self=[super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        
    }
    return self;
}
- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
