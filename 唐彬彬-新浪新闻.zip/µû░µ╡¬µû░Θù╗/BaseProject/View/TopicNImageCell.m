//
//  TopicNImageCell.m
//  新浪新闻
//
//  Created by apple-jd18 on 15/11/22.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "TopicNImageCell.h"

@implementation TopicNImageCell
-(UILabel *)titleLbN{
    if (!_titleLbN) {
        _titleLbN = [[UILabel alloc]init ];
        _titleLbN.font = [UIFont systemFontOfSize:15];
        [self.contentView addSubview:_titleLbN];
        [self.titleLbN mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(3);
            make.right.mas_equalTo(-3);
            make.top.mas_equalTo(3);
            make.height.mas_equalTo(20);
        }];
    }
    return _titleLbN;
}


-(UILabel *)introLbN{
    if (!_introLbN) {
        _introLbN = [[UILabel alloc]init ];
        _introLbN.font  = [UIFont systemFontOfSize:13];
        _introLbN.textColor = [UIColor lightGrayColor];
        _introLbN.numberOfLines = 0;
        [self.contentView addSubview:_introLbN];
        [self.introLbN mas_makeConstraints:^(MASConstraintMaker *make) {

            make.top.mas_equalTo(self.titleLbN.mas_bottom).mas_equalTo(2);
            make.right.mas_equalTo(-3);
            make.left.mas_equalTo(3);
//            make.bottom.mas_equalTo(self.commentLbN.mas_top).mas_equalTo(-2);
            make.height.mas_equalTo(45);
        }];
    }
    return _introLbN;
}

-(UILabel *)commentLbN{
    if (!_commentLbN) {
        _commentLbN = [[UILabel alloc]init ];
        _commentLbN.font = [UIFont systemFontOfSize:11];
        _commentLbN.textColor = [UIColor lightGrayColor];
        [self.contentView addSubview:_commentLbN];
        [self.commentLbN mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.mas_equalTo(-3);
//            make.bottom.mas_equalTo(-8);
//            make.right.mas_equalTo(self.commentLbN.mas_left).mas_equalTo(-3);
            make.top.mas_equalTo(self.introLbN.mas_bottom).mas_equalTo(-3);
            make.size.mas_equalTo(CGSizeMake(75, 10));
            
        }];
        
    }
    return _commentLbN;
}





-(id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self=[super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        
    }
    return self;
}
- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
