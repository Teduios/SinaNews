//
//  SearchNimCell.m
//  新浪新闻
//
//  Created by apple-jd18 on 15/11/23.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "SearchNimCell.h"

@implementation SearchNimCell
-(UILabel *)titleLbN{
    if (!_titleLbN) {
        _titleLbN = [[UILabel alloc]init ];
        _titleLbN.font = [UIFont systemFontOfSize:15];
        [self.contentView addSubview:_titleLbN];
        [self.titleLbN mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(3);
            make.right.mas_equalTo(-3);
            make.top.mas_equalTo(3);
            make.height.mas_equalTo(18);
        }];
    }
    return _titleLbN;
}
-(UILabel *)contentLbN{
    if (!_contentLbN) {
        _contentLbN = [[UILabel alloc]init ];
        _contentLbN.numberOfLines = 0;
        _contentLbN.font = [UIFont systemFontOfSize:13];
        _contentLbN.textColor = [UIColor lightGrayColor];
        
        [self.contentView addSubview:_contentLbN];
        [self.contentLbN mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(3);
            make.top.mas_equalTo(self.titleLbN.mas_bottom).mas_equalTo(3);
            make.right.mas_equalTo(-3);
            make.height.mas_equalTo(55);
        }];
    }
    return _contentLbN;
}

-(UILabel *)pushTimeLbN{
    if (!_pushTimeLbN) {
        _pushTimeLbN = [[UILabel alloc]init ];
        _pushTimeLbN.font = [UIFont systemFontOfSize:11];
        _pushTimeLbN.textColor = [UIColor lightGrayColor];
        [self.contentView addSubview:_pushTimeLbN];
        [self.pushTimeLbN mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.mas_equalTo(-4);
            make.top.mas_equalTo(self.contentLbN.mas_bottom).mas_equalTo(3);
            make.size.mas_equalTo(CGSizeMake(120, 10));
        }];
    }
    return _pushTimeLbN;
}

-(id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self=[super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        
    }
    return self;
}
- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
