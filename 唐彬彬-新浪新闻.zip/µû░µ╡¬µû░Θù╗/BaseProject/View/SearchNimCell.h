//
//  SearchNimCell.h
//  新浪新闻
//
//  Created by apple-jd18 on 15/11/23.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SearchNimCell : UITableViewCell
@property(nonatomic,strong)UILabel *titleLbN;
@property(nonatomic,strong)UILabel *contentLbN;
@property(nonatomic,strong)UILabel *pushTimeLbN;

@end
