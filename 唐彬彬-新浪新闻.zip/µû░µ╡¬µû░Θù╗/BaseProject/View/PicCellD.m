//
//  PicCellD.m
//  BaseProject
//
//  Created by tangbinbin on 15/11/11.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "PicCellD.h"

@implementation PicCellD
-(UILabel *)introLbD{
    if (!_introLbD) {
        _introLbD = [[UILabel alloc]init ];
        _introLbD.font = [UIFont systemFontOfSize:14];
        _introLbD.numberOfLines = 0;
        _introLbD.textColor = [UIColor lightGrayColor];
        [self.contentView addSubview:_introLbD];
        [self.introLbD mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(3);
            make.bottom.mas_equalTo(-3);
            make.right.mas_equalTo(-3);
//            make.height.mas_lessThanOrEqualTo(50);
//            make.height.mas_lessThanOrEqualTo(25);
            make.height.mas_equalTo(45);
        }];
    }
    return _introLbD;
}
-(UILabel *)commentLbD{
    if (!_commentLbD) {
        _commentLbD = [[UILabel alloc]init ];
        _commentLbD.textColor = [UIColor lightGrayColor];
        _commentLbD.font = [UIFont systemFontOfSize:12];
        [self.contentView addSubview:_commentLbD];
        [self.commentLbD mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.mas_equalTo(-3);
            make.bottom.mas_equalTo(self.introLbD.mas_top).mas_equalTo(-10);
            make.size.mas_equalTo(CGSizeMake(60, 10));
        }];
    }
    return _commentLbD;
}

-(UILabel *)titleLbD{
    if (!_titleLbD) {
        _titleLbD = [[UILabel alloc]init ];
        _titleLbD.font = [UIFont systemFontOfSize:15];
        [self.contentView addSubview:_titleLbD];
        [self.titleLbD mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(3);
            make.bottom.mas_equalTo(self.introLbD.mas_top).mas_equalTo(-3);
            make.height.mas_equalTo(20);
            make.right.mas_equalTo(self.commentLbD.mas_left).mas_equalTo(-4);
        }];
    }
    return _titleLbD;
}

-(TRImageView *)iconIVD1{
    if (!_iconIVD1) {
        _iconIVD1 = [[TRImageView alloc]init ];
        [self.contentView addSubview:_iconIVD1];
        [self.iconIVD1 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(0);
            make.top.mas_equalTo(3);
            make.size.mas_equalTo(CGSizeMake(kWindowW/2-1,100));
        }];
    }
    return _iconIVD1;
}
-(TRImageView *)iconIVD2{
    if (!_iconIVD2) {
        _iconIVD2 = [[TRImageView alloc]init ];
        [self.contentView addSubview:_iconIVD2];
        [self.iconIVD2 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.mas_equalTo(0);
            make.top.mas_equalTo(3);
//            make.size.mas_equalTo(_iconIVD1);
            make.size.mas_equalTo(CGSizeMake(kWindowW/2-1,100));
        }];
    }
    return _iconIVD2;
}

-(TRImageView *)iconIVD3{
    if (!_iconIVD3) {
        _iconIVD3 = [[TRImageView alloc]init ];
        [self.contentView addSubview:_iconIVD3];
        [self.iconIVD3 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(0);
            make.top.mas_equalTo(self.iconIVD1.mas_bottom).mas_equalTo(2);
//            make.size.mas_equalTo(_iconIVD1);
            make.size.mas_equalTo(CGSizeMake(kWindowW/2-1,100));
        }];
    
    }
    return _iconIVD3;
}
-(TRImageView *)iconIVD4{
    if (!_iconIVD4) {
        _iconIVD4 = [[TRImageView alloc]init ];
        [self.contentView addSubview:_iconIVD4];
        [self.iconIVD4 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.mas_equalTo(0);
            make.top.mas_equalTo(self.iconIVD2.mas_bottom).mas_equalTo(2);
//            make.size.mas_equalTo(_iconIVD1);
            make.size.mas_equalTo(CGSizeMake(kWindowW/2-1,100));
        }];
    }
    return _iconIVD4;
}
- (void)awakeFromNib {
    // Initialization code
}

-(id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self=[super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        
    }
    return self;
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
