//
//  PicCellA.h
//  BaseProject
//
//  Created by apple-jd18 on 15/11/11.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TRImageView.h"
@interface PicCellA : UITableViewCell
//**标题标签*/
@property(nonatomic,strong)UILabel *titleLbA;
//**详情标签*/
@property(nonatomic,strong)UILabel *introLbA;
//评论标签/
@property(nonatomic,strong)UILabel *commentLbA;


//**图片*/
@property(nonatomic,strong)TRImageView *iconIVA1;
@property(nonatomic,strong)TRImageView *iconIVA2;
@end
