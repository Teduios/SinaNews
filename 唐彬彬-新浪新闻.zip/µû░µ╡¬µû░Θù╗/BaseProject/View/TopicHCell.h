//
//  TopicHCell.h
//  新浪新闻
//
//  Created by apple-jd18 on 15/11/22.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TopicHCell : UITableViewCell
@property(nonatomic,strong)UILabel *headTitleLb;
@end
