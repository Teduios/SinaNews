//
//  TopicHCell.m
//  新浪新闻
//
//  Created by apple-jd18 on 15/11/22.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "TopicHCell.h"

@implementation TopicHCell

-(UILabel *)headTitleLb{
    if (!_headTitleLb) {
        _headTitleLb = [[UILabel alloc]init ];
        _headTitleLb.font = [UIFont systemFontOfSize:14];
        _headTitleLb.textColor = [UIColor redColor];
        [self.contentView addSubview:_headTitleLb];
        [_headTitleLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(4);
            make.top.mas_equalTo(3);
            make.size.mas_equalTo(CGSizeMake(75,17 ));
        }];
    }
    return _headTitleLb;
}


- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
