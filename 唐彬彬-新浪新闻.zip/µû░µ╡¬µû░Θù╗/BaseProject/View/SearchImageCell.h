//
//  SearchImageCell.h
//  新浪新闻
//
//  Created by apple-jd18 on 15/11/23.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TRImageView.h"
@interface SearchImageCell : UITableViewCell
@property(nonatomic,strong)UILabel *titleLB;
@property(nonatomic,strong)UILabel *contentLb;
@property(nonatomic,strong)UILabel *pushTimeLb;
@property(nonatomic,strong)TRImageView *imageIVS;
@end
