//
//  SearchImageCell.m
//  新浪新闻
//
//  Created by apple-jd18 on 15/11/23.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "SearchImageCell.h"

@implementation SearchImageCell
-(TRImageView *)imageIVS{
    if (!_imageIVS) {
        _imageIVS = [[TRImageView alloc]init ];
        [self.contentView addSubview:_imageIVS];
        [self.imageIVS mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(3);
            make.top.mas_equalTo(3);
            make.size.mas_equalTo(CGSizeMake(85, 65));
        
        }];
    }
    return _imageIVS;
}
-(UILabel *)titleLB{
    if (!_titleLB) {
    _titleLB = [[UILabel alloc]init ];
    _titleLB.font = [UIFont systemFontOfSize:15];
    [self.contentView addSubview:_titleLB];
    [self.titleLB mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.imageIVS.mas_right).mas_equalTo(3);
        make.right.mas_equalTo(-3);
        make.top.mas_equalTo(3);
        make.height.mas_equalTo(18);
    }];
    }
    return _titleLB;
}
-(UILabel *)contentLb{
    if (!_contentLb) {
        _contentLb = [[UILabel alloc]init ];
        
        _contentLb.font = [UIFont systemFontOfSize:13];
        _contentLb.textColor = [UIColor lightGrayColor];
         _contentLb.numberOfLines = 0;
        [self.contentView addSubview:_contentLb];
        [self.contentLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(self.imageIVS.mas_right).mas_equalTo(3);
            make.top.mas_equalTo(self.titleLB.mas_bottom).mas_equalTo(3);
            make.right.mas_equalTo(-3);
            make.height.mas_equalTo(55);
        }];
    }
    return _contentLb;
}

-(UILabel *)pushTimeLb{
    if (!_pushTimeLb) {
        _pushTimeLb = [[UILabel alloc]init ];
        _pushTimeLb.font = [UIFont systemFontOfSize:11];
        _pushTimeLb.textColor = [UIColor lightGrayColor];
       
        [self.contentView addSubview:_pushTimeLb];
        [self.pushTimeLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.mas_equalTo(-4);
            make.top.mas_equalTo(self.contentLb.mas_bottom).mas_equalTo(3);
            make.size.mas_equalTo(CGSizeMake(120, 10));
        }];
    }
    return _pushTimeLb;
}


-(id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self=[super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        
    }
    return self;
}
- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
