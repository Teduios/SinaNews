//
//  VideoLatestCell.h
//  BaseProject
//
//  Created by tangbinbin on 15/11/5.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface VideoLatestCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIButton *VideoBtn;
@property (weak, nonatomic) IBOutlet UILabel *longTitle;
@property (weak, nonatomic) IBOutlet UILabel *playNumber;
@property(nonatomic,strong)NSURL *videoUrlV;

@end
