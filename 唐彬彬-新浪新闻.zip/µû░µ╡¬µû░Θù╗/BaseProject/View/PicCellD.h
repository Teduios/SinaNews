//
//  PicCellD.h
//  BaseProject
//
//  Created by tangbinbin on 15/11/11.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TRImageView.h"
@interface PicCellD : UITableViewCell
//**标题标签*/
@property(nonatomic,strong)UILabel *titleLbD;
//**详情标签*/
@property(nonatomic,strong)UILabel *introLbD;
//评论标签/
@property(nonatomic,strong)UILabel *commentLbD;

@property(nonatomic,strong)TRImageView *iconIVD1;
@property(nonatomic,strong)TRImageView *iconIVD2;
@property(nonatomic,strong)TRImageView *iconIVD3;
@property(nonatomic,strong)TRImageView *iconIVD4;
@end
