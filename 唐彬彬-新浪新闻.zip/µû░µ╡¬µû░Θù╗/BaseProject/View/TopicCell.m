//
//  TopicCell.m
//  新浪新闻
//
//  Created by apple-jd18 on 15/11/18.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "TopicCell.h"

@implementation TopicCell
-(TRImageView *)iconIVT{
    if (!_iconIVT) {
        _iconIVT = [[TRImageView alloc]init ];
        [self.contentView addSubview:_iconIVT];
        [self.iconIVT mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(3);
            make.top.mas_equalTo(4);
            make.size.mas_equalTo(CGSizeMake(85, 65));
            
        }];
    }
    return _iconIVT;
}

-(UILabel *)titleLb{
    if (!_titleLb) {
        _titleLb = [[UILabel alloc]init ];
        _introLb.font  = [UIFont systemFontOfSize:15];
        [self.contentView addSubview:_titleLb];
        [self.titleLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(self.iconIVT.mas_right).mas_equalTo(3);
            make.top.mas_equalTo(4);
            make.right.mas_equalTo(-3);
            make.height.mas_equalTo(20);
}];
    }
    return _titleLb;
}
-(UILabel *)introLb{
    if (!_introLb) {
        _introLb = [[UILabel alloc]init ];
        
        _introLb.font  = [UIFont systemFontOfSize:13];
        _introLb.textColor = [UIColor lightGrayColor];
        _introLb.numberOfLines = 0;
        [self.contentView addSubview:_introLb];
        [self.introLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(self.iconIVT.mas_right).mas_equalTo(3);
            make.top.mas_equalTo(self.titleLb.mas_bottom).mas_equalTo(2);
            make.right.mas_equalTo(-3);
//            make.bottom.mas_equalTo(self.commentLb.mas_top).mas_equalTo(-2);
            make.height.mas_equalTo(45);
//            make.bottom.mas_equalTo(self.commentLb.mas_top).mas_equalTo(-2);
            
        }];
    }
    return _introLb;
}



-(UILabel *)commentLb{
    if (!_commentLb) {
        _commentLb = [[UILabel alloc]init ];
        _commentLb.font = [UIFont systemFontOfSize:11];
        _commentLb.textColor = [UIColor lightGrayColor];
        [self.contentView addSubview:_commentLb];
        [self.commentLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.mas_equalTo(-3);
//            make.bottom.mas_equalTo(-3);
            make.top.mas_equalTo(self.introLb.mas_bottom).mas_equalTo(3);
            make.size.mas_equalTo(CGSizeMake(75, 10));
            
        }];
        
    }
    return _commentLb;
}
-(id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self=[super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        
    }
    return self;
}
- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
