//
//  PicCellC.h
//  BaseProject
//
//  Created by apple-jd18 on 15/11/11.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TRImageView.h"
@interface PicCellC : UITableViewCell
//**标题标签*/
@property(nonatomic,strong)UILabel *titleLbC;
//**详情标签*/
@property(nonatomic,strong)UILabel *introLbC;
//评论标签/
@property(nonatomic,strong)UILabel *commentLbC;

//**图片*/
@property(nonatomic,strong)TRImageView *iconIVC1;
@property(nonatomic,strong)TRImageView *iconIVC2;
@property(nonatomic,strong)TRImageView *iconIVC3;

@end
