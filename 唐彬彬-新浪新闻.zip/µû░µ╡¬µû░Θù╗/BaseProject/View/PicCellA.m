//
//  PicCellA.m
//  BaseProject
//
//  Created by apple-jd18 on 15/11/11.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "PicCellA.h"

@implementation PicCellA
-(UILabel *)introLbA{
    if (!_introLbA) {
        _introLbA = [[UILabel alloc]init ];
        _introLbA.font = [UIFont systemFontOfSize:14];
        _introLbA.numberOfLines = 0;
        _introLbA.textColor = [UIColor lightGrayColor];
        [self.contentView addSubview:_introLbA];
        [self.introLbA mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(3);
            make.bottom.mas_equalTo(-3);
            make.right.mas_equalTo(-3);
//            make.height.mas_lessThanOrEqualTo(50);
//            make.height.mas_lessThanOrEqualTo(25);
            make.height.mas_equalTo(45);
        }];
    }
    return _introLbA;
}
-(UILabel *)commentLbA{
    if (!_commentLbA) {
        _commentLbA = [[UILabel alloc]init ];
        _commentLbA.textColor = [UIColor lightGrayColor];
        _commentLbA.font = [UIFont systemFontOfSize:12];
        [self.contentView addSubview:_commentLbA];
        [self.commentLbA mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.mas_equalTo(-3);
            make.bottom.mas_equalTo(self.introLbA.mas_top).mas_equalTo(-10);
            make.size.mas_equalTo(CGSizeMake(60, 10));
        }];
    }
    return _commentLbA;
}

-(UILabel *)titleLbA{
    if (!_titleLbA) {
        _titleLbA = [[UILabel alloc]init ];
        _titleLbA.font = [UIFont systemFontOfSize:15];
        [self.contentView addSubview:_titleLbA];
        [self.titleLbA mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(3);
            make.bottom.mas_equalTo(self.introLbA.mas_top).mas_equalTo(-3);
            make.height.mas_equalTo(20);
            make.right.mas_equalTo(self.commentLbA.mas_left).mas_equalTo(-4);
        }];
    }
    return _titleLbA;
}

-(TRImageView *)iconIVA1{
    if (!_iconIVA1) {
        _iconIVA1 = [[TRImageView alloc]init ];
        [self.contentView addSubview:_iconIVA1];
        [self.iconIVA1 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(0);
            make.top.mas_equalTo(3);
//            make.bottomMargin.mas_equalTo(_titleLbA.mas_topMargin).mas_equalTo(3);
            
//            make.width.mas_equalTo(kWindowW/2-1);
            make.size.mas_equalTo(CGSizeMake(kWindowW/2-1, 202));
        }];
    }
    return _iconIVA1;
}
-(TRImageView *)iconIVA2{
    if (!_iconIVA2) {
        _iconIVA2 = [[TRImageView alloc]init ];
        [self.contentView addSubview:_iconIVA2];
        
        [self.iconIVA2 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.mas_equalTo(0);
            make.top.mas_equalTo(3);
//            make.bottomMargin.mas_equalTo(_titleLbA.mas_topMargin).mas_equalTo(3);
//            make.size.mas_equalTo(_iconIVA1);
            make.size.mas_equalTo(CGSizeMake(kWindowW/2-1, 202));
        
        }];
    }
    return _iconIVA2;
}

-(id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self=[super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        
    }
    return self;
}
- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
