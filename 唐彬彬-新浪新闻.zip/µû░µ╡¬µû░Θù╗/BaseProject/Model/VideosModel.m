//
//  VideosModel.m
//  BaseProject
//
//  Created by tangbinbin on 15/11/5.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "VideosModel.h"

@implementation VideosModel

@end

@implementation VideosDataModel
+ (NSDictionary *)objectClassInArray{
    return @{@"list":[VideosDataListModel class]};
}


+(NSDictionary *)replacedKeyFromPropertyName{
    return @{@"isIntro":@"is_intro"};
}
@end

@implementation VideosDataListModel
+(NSDictionary *)replacedKeyFromPropertyName{
    return @{@"ID":@"id",@"longTitle":@"long_title",@"videoInfo":@"video_info"};
    
}

+(NSDictionary *)objectClassInArray{
    return @{@"videoInfo":[VideosDataListVideoInfoModel class]};
}
@end

@implementation VideosDataListVideoInfoModel
+(NSDictionary *)replacedKeyFromPropertyName{
    return @{@"videoId":@"video_id"};
}
@end