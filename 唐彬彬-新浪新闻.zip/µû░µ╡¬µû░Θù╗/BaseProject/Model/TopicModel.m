//
//  TopicModel.m
//  新浪新闻
//
//  Created by apple-jd18 on 15/11/18.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "TopicModel.h"

@implementation TopicModel

@end


@implementation PopicDataModel

+ (NSDictionary *)objectClassInArray{
    return @{@"news" : [TopicDataNewsModel class]};
}
+(NSDictionary *)replacedKeyFromPropertyName{
    return @{@"ID":@"id"};
}
@end


@implementation TopicDataNewsModel

+ (NSDictionary *)objectClassInArray{
    return @{@"list" : [TopicDataNewsListModel class]};
}

@end


@implementation TopicDataNewsListModel
+(NSDictionary *)replacedKeyFromPropertyName{
    return @{@"ID":@"id"};
}
@end


@implementation TopicDatanewsListComment_Count_InfoModel

@end


