//
//  SearchModel.m
//  新浪新闻
//
//  Created by apple-jd18 on 15/11/23.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "SearchModel.h"

@implementation SearchModel


+ (NSDictionary *)objectClassInArray{
    return @{@"result" : [SearchResultModel class]};
}
@end
@implementation SearchResultModel

@end


