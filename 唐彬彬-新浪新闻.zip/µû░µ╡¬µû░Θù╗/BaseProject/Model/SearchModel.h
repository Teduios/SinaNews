//
//  SearchModel.h
//  新浪新闻
//
//  Created by apple-jd18 on 15/11/23.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseModel.h"

@class SearchResultModel;
@interface SearchModel : BaseModel

@property (nonatomic, strong) NSArray<SearchResultModel *> *result;

@property (nonatomic, assign) NSInteger error_code;

@property (nonatomic, copy) NSString *reason;

@end
@interface SearchResultModel : NSObject

@property (nonatomic, copy) NSString *full_title;

@property (nonatomic, copy) NSString *content;

@property (nonatomic, copy) NSString *img;

@property (nonatomic, copy) NSString *src;

@property (nonatomic, copy) NSString *img_length;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, copy) NSString *img_width;

@property (nonatomic, copy) NSString *pdate;

@property (nonatomic, copy) NSString *pdate_src;

@property (nonatomic, copy) NSString *url;

@end

