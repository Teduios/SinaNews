//
//  WeatherModel.m
//  新浪新闻
//
//  Created by apple-jd18 on 15/11/27.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "WeatherModel.h"

@implementation WeatherModel

@end
@implementation WeatherResultModel

+ (NSDictionary *)objectClassInArray{
    return @{@"future" : [WeatherResultFutureModel class]};
}

@end


@implementation WeatherResultSkModel

@end


@implementation WeatherResultTodayModel

@end


@implementation WeatherResultFutureModel

@end


