//
//  PicModel.h
//  BaseProject
//
//  Created by apple-jd18 on 15/11/7.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseModel.h"


@class PicDataModel,PicDataListModel,PicDataListPicsModel,PicDataListPicsListModel,PicDatalistComment_Count_Info;
@interface PicModel : BaseModel
@property (nonatomic, assign) NSInteger status;

@property (nonatomic, strong) PicDataModel *data;
@end



@interface PicDataModel : NSObject

@property (nonatomic, copy) NSString *is_intro;

@property (nonatomic, strong) NSArray<PicDataListModel *> *list;

@end

@interface PicDataListModel : NSObject

@property (nonatomic, copy) NSString *ID;

@property (nonatomic, copy) NSString *intro;

@property (nonatomic, copy) NSString *kpic;

@property (nonatomic, copy) NSString *comments;

@property (nonatomic, copy) NSString *feedShowStyle;

@property (nonatomic, copy) NSString *category;

@property (nonatomic, copy) NSString *link;

@property (nonatomic, assign) NSInteger pubDate;

@property (nonatomic, copy) NSString *source;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, copy) NSString *pic;

@property (nonatomic, assign) NSNumber *comment;

@property (nonatomic, strong) PicDatalistComment_Count_Info *comment_count_info;

@property (nonatomic, copy) NSString *long_title;

@property (nonatomic, strong) PicDataListPicsModel *pics;

@end

@interface PicDataListPicsModel : NSObject

@property (nonatomic, assign) NSInteger total;

@property (nonatomic, assign) NSInteger picTemplate;

@property (nonatomic, strong) NSArray<PicDataListPicsListModel *> *list;

@end

@interface PicDataListPicsListModel : NSObject

@property (nonatomic, copy) NSString *pic;

@property (nonatomic, copy) NSString *alt;

@property (nonatomic, copy) NSString *kpic;

@end

@interface PicDatalistComment_Count_Info : NSObject

@property (nonatomic, assign) NSInteger comment_status;

@property (nonatomic, assign) NSInteger qreply;

@property (nonatomic, assign) NSInteger show;

@property (nonatomic, assign) NSInteger dispraise;

@property (nonatomic, assign) NSInteger total;

@property (nonatomic, assign) NSInteger praise;

@end

