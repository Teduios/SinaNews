//
//  TopicModel.h
//  新浪新闻
//
//  Created by apple-jd18 on 15/11/18.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseModel.h"


@class PopicDataModel,TopicDataNewsModel,TopicDataNewsListModel,TopicDatanewsListComment_Count_InfoModel;
@interface TopicModel : BaseModel

@property (nonatomic, assign) NSInteger status;

@property (nonatomic, strong) PopicDataModel *data;

@end

@interface PopicDataModel : NSObject

@property (nonatomic, strong) NSArray<TopicDataNewsModel *> *news;

@property (nonatomic, copy) NSString *comments;

@property (nonatomic, copy) NSString *banner_pic;

@property (nonatomic, copy) NSString *ID;

@property (nonatomic, assign) BOOL banner_include_title;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, copy) NSString *link;

@property (nonatomic, copy) NSString *intro;

@end

@interface TopicDataNewsModel : NSObject

@property (nonatomic, copy) NSString *title;

@property (nonatomic, copy) NSString *module;

@property (nonatomic, strong) NSArray<TopicDataNewsListModel *> *list;

@end

@interface TopicDataNewsListModel : NSObject

@property (nonatomic, copy) NSString *id;

@property (nonatomic, copy) NSString *intro;

@property (nonatomic, copy) NSString *kpic;

@property (nonatomic, copy) NSString *comments;

@property (nonatomic, copy) NSString *feedShowStyle;

@property (nonatomic, copy) NSString *category;

@property (nonatomic, copy) NSString *link;

@property (nonatomic, copy) NSString *bpic;

@property (nonatomic, assign) NSInteger pubDate;

@property (nonatomic, copy) NSString *source;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, copy) NSString *pic;

@property (nonatomic, assign) NSNumber *comment;

@property (nonatomic, strong) TopicDatanewsListComment_Count_InfoModel *comment_count_info;

@property (nonatomic, copy) NSString *long_title;

@end

@interface TopicDatanewsListComment_Count_InfoModel : NSObject

@property (nonatomic, assign) NSInteger comment_status;

@property (nonatomic, assign) NSInteger qreply;

@property (nonatomic, assign) NSInteger show;

@property (nonatomic, assign) NSInteger dispraise;

@property (nonatomic, assign) NSInteger total;

@property (nonatomic, assign) NSInteger praise;

@end

