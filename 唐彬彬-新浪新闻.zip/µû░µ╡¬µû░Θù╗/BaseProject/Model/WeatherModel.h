//
//  WeatherModel.h
//  新浪新闻
//
//  Created by apple-jd18 on 15/11/27.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseModel.h"

@class WeatherResultModel,WeatherResultSkModel,WeatherResultTodayModel,WeatherResultFutureModel;
@interface WeatherModel : BaseModel

@property (nonatomic, assign) NSInteger error_code;

@property (nonatomic, strong) WeatherResultModel *result;

@property (nonatomic, copy) NSString *reason;

@end
@interface WeatherResultModel : NSObject

@property (nonatomic, strong) WeatherResultSkModel *sk;

@property (nonatomic, strong) WeatherResultTodayModel *today;

@property (nonatomic, strong) NSArray<WeatherResultFutureModel *> *future;

@end

@interface WeatherResultSkModel : NSObject

@property (nonatomic, copy) NSString *humidity;

@property (nonatomic, copy) NSString *wind_direction;

@property (nonatomic, copy) NSString *temp;

@property (nonatomic, copy) NSString *wind_strength;

@property (nonatomic, copy) NSString *time;

@end

@interface WeatherResultTodayModel : NSObject

@property (nonatomic, copy) NSString *drying_index;

@property (nonatomic, copy) NSString *temperature;

@property (nonatomic, copy) NSString *dressing_index;

@property (nonatomic, copy) NSString *dressing_advice;

@property (nonatomic, copy) NSString *uv_index;

@property (nonatomic, copy) NSString *comfort_index;

@property (nonatomic, copy) NSString *wind;

@property (nonatomic, copy) NSString *weather;

@property (nonatomic, copy) NSString *city;

@property (nonatomic, copy) NSString *date_y;

@property (nonatomic, copy) NSString *week;

@property (nonatomic, copy) NSString *fa;

@property (nonatomic, copy) NSString *wash_index;

@property (nonatomic, copy) NSString *travel_index;

@property (nonatomic, copy) NSString *exercise_index;

@property (nonatomic, copy) NSString *fb;

@end

@interface WeatherResultFutureModel : NSObject

@property (nonatomic, copy) NSString *wind;

@property (nonatomic, copy) NSString *week;

@property (nonatomic, copy) NSString *date;

@property (nonatomic, copy) NSString *temperature;

@property (nonatomic, copy) NSString *weather;

@property (nonatomic, copy) NSString *fa;

@property (nonatomic, copy) NSString *fb;

@end

