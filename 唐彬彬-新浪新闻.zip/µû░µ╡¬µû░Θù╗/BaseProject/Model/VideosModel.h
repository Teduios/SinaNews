//
//  VideosModel.h
//  BaseProject
//
//  Created by tangbinbin on 15/11/5.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseModel.h"
@class VideosDataModel,VideosDataListVideoInfoModel,VideosDataListModel;
@interface VideosModel : BaseModel
@property (nonatomic, assign) double status;
@property (nonatomic, strong) VideosDataModel *data;
@end

@interface VideosDataModel : BaseModel
@property (nonatomic, strong) NSString *isIntro;
@property (nonatomic, strong) NSArray *list;
@end

@interface VideosDataListModel : BaseModel
@property (nonatomic, strong) NSString *ID;
@property (nonatomic, strong) NSString *category;
@property (nonatomic, strong) NSString *comments;
@property (nonatomic, strong) NSString *kpic;
@property (nonatomic, strong) NSString *intro;
@property (nonatomic, strong) NSString *feedShowStyle;
@property (nonatomic, strong) NSString *link;
@property (nonatomic, assign) double pubDate;
@property (nonatomic, strong) NSString *source;
@property (nonatomic, strong) NSString *pic;
@property (nonatomic, strong) NSString *title;
@property (nonatomic, strong) VideosDataListVideoInfoModel *videoInfo;
@property (nonatomic, strong) NSString *longTitle;
@end

@interface VideosDataListVideoInfoModel : BaseModel
@property (nonatomic, strong) NSString *pic;
@property (nonatomic, strong) NSString *runtime;
@property (nonatomic, strong) NSString *kpic;
@property (nonatomic, assign) NSNumber *playnumber;
@property (nonatomic, strong) NSString *videoId;
@property (nonatomic, strong) NSString *type;
@property (nonatomic, assign) BOOL widtwidth;
@property (nonatomic, strong) NSString *url;
@end