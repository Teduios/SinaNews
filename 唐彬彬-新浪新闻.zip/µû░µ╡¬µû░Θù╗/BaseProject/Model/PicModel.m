//
//  PicModel.m
//  BaseProject
//
//  Created by apple-jd18 on 15/11/7.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "PicModel.h"

@implementation PicModel

@end



@implementation PicDataModel

+ (NSDictionary *)objectClassInArray{
    return @{@"list" : [PicDataListModel class]};
}

@end


@implementation PicDataListModel
+ (NSDictionary *)replacedKeyFromPropertyName{
    return @{
             @"ID":@"id"
        };
}
@end


@implementation PicDataListPicsModel

+ (NSDictionary *)objectClassInArray{
    return @{@"list" : [PicDataListPicsListModel class]};
}

@end


@implementation PicDataListPicsListModel

@end


@implementation PicDatalistComment_Count_Info

@end


