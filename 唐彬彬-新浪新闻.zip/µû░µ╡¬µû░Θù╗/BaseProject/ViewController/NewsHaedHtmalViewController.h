//
//  NewsHaedHtmalViewController.h
//  BaseProject
//
//  Created by tangbinbin on 15/11/14.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NewsHaedHtmalViewController : UIViewController
- (id)initWithURL:(NSURL *)url;
@property(nonatomic,strong) NSURL *url;
@end
