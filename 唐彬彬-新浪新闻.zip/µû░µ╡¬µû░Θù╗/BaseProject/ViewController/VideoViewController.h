//
//  VideoViewController.h
//  BaseProject
//
//  Created by tangbinbin on 15/11/5.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "VideosNetManager.h"
@interface VideoViewController : UIViewController
@property(nonatomic)VideosListType typeV;
@end
