//
//  SearchHtmlController.h
//  新浪新闻
//
//  Created by apple-jd18 on 15/11/23.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SearchHtmlController : UIViewController
- (id)initWithURL:(NSURL *)url;
@property(nonatomic,strong)NSURL *url;
@end
