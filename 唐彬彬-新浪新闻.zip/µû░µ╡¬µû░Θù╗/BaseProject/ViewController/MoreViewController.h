//
//  MoreViewController.h
//  新浪新闻
//
//  Created by apple-jd18 on 15/11/27.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Factory.h"
#import "AddressChoicePickerView.h"
#import "WeahterCell.h"
@interface MoreViewController : UITableViewController
@property (weak, nonatomic) IBOutlet UIButton *goPickerBu;
//日期
@property (weak, nonatomic) IBOutlet UILabel *dateYLB;
//几点
@property (weak, nonatomic) IBOutlet UILabel *skTimeLb;
//实时温度
@property (weak, nonatomic) IBOutlet UILabel *skTemperatureLb;
@property (weak, nonatomic) IBOutlet UIImageView *todayImage;
//fa
@property (weak, nonatomic) IBOutlet UILabel *faLb;
//温度区间
@property (weak, nonatomic) IBOutlet UILabel *todayTemperatureLb;
@property (weak, nonatomic) IBOutlet UILabel *tempLb;
//风
@property (weak, nonatomic) IBOutlet UILabel *todayWindLb;
//穿依指数
@property (weak, nonatomic) IBOutlet UILabel *todaydressing_advicelb;
@property(nonatomic,strong)NSString *cityName;
@end
