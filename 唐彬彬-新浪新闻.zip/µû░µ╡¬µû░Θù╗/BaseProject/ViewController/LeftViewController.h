//
//  LeftViewController.h
//  新浪新闻
//
//  Created by apple-jd18 on 15/11/24.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MenuView.h"
@interface LeftViewController : UIViewController

@end
