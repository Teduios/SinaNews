//
//  SearchViewController.m
//  新浪新闻
//
//  Created by apple-jd18 on 15/11/23.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "SearchViewController.h"
#import "SearchViewModel.h"
#import "SearchImageCell.h"
#import "SearchNimCell.h"
#import "SearchHtmlController.h"
#import "Factory.h"
@interface SearchViewController ()
@property(nonatomic,strong)SearchViewModel *SVCM;
@end

@implementation SearchViewController
-(SearchViewModel *)SVCM{
    if (!_SVCM) {

        _SVCM = [[SearchViewModel alloc]initWithSearchNewsKeyWords:_textString ];
          DDLogVerbose(@"SVCM....%@....",self.textString);
    }
    return _SVCM;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    [self.tableView setSeparatorColor:[UIColor redColor]];
    [self.tableView registerClass:[SearchNimCell class] forCellReuseIdentifier:@"NCell"];
    [self.tableView registerClass:[SearchImageCell class] forCellReuseIdentifier:@"ICell"];
    [self.SVCM getDataFromNetCompleteHandle:^(NSError *error) {
        [self.tableView reloadData];

    }];
    [Factory addBackItemToVC:self];
//    DDLogVerbose(@"....%@....",self.textString);

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {

    return self.SVCM.rowNumberS;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

    return 1;
}
//设置section头部高度1像素， 高度最小是1
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 2;
}
//设置secion脚部高度9像素
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 9;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if ([self.SVCM imageViewForRow:indexPath.section]) {
//        if ([self.SVCM imageIVForRow:indexPath.section]) {

        SearchNimCell *NCell = [tableView dequeueReusableCellWithIdentifier:@"NCell"];
        NCell.titleLbN.text = [self.SVCM titleForRow:indexPath.section];
        NCell.contentLbN.text = [self.SVCM contentForRow:indexPath.section];
        NCell.pushTimeLbN.text = [self.SVCM pushTimeForRow:indexPath.section];
    
        return NCell;
    }else{
        SearchImageCell *ICell = [tableView dequeueReusableCellWithIdentifier:@"ICell"];
        ICell.titleLB.text = [self.SVCM titleForRow:indexPath.section];
        ICell.pushTimeLb.text = [self.SVCM pushTimeForRow:indexPath.section];
        ICell.contentLb.text = [self.SVCM contentForRow:indexPath.section];
        [ICell.imageIVS.imageView setImageWithURL:[self.SVCM imageIVForRow:indexPath.section]];
        return ICell;
    }
}
kRemoveCellSeparator
-(void)tableView:(UITableView *)tableview didSelectRowAtIndexPath:(nonnull NSIndexPath *)indexPath{
    [tableview deselectRowAtIndexPath:indexPath animated:YES];
    SearchHtmlController *vc = [[SearchHtmlController alloc]initWithURL:[self.SVCM searHtmlForRow:indexPath.section] ];
    
    [self.navigationController pushViewController:vc animated:YES];

}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 100;
}
/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
