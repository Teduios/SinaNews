//
//  MenuView.m
//  新浪新闻
//
//  Created by apple-jd18 on 15/11/30.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "MenuView.h"

@interface MenuView ()
@property (weak, nonatomic) IBOutlet UITextField *textFile;
@property(nonatomic,strong)MenuObject *menu;

@end


@implementation MenuView
-(id)init{
    if (self = [super init]) {
        self = [[[NSBundle mainBundle]loadNibNamed:@"MenuView" owner:nil options:nil]firstObject];
        self.frame = [UIScreen mainScreen].bounds;
        self.menu.menuNmae = self.textFile.text;
        [self layoutIfNeeded];
    }
    return self;
}

-(MenuObject *)menu{
    if (!_menu) {
        _menu = [[MenuObject alloc]init ];
    }
    return _menu;
}

- (IBAction)goSearchView:(id)sender {
    if (self.block) {
        self.block(self,sender,self.menu);
    }
    [self hideMune];
}
- (IBAction)dissMenu:(id)sender {
    [self hideMune];
}

-(void)showSearchView{
    UIWindow *win  = [[UIApplication sharedApplication]keyWindow ];
    UIView *topView = [win.subviews firstObject];
    [topView addSubview:self];
    [UIView animateWithDuration:0.3 animations:^{
        [self layoutIfNeeded];
    }];
}
-(void)hideMune{
    [UIView animateWithDuration:0.3 animations:^{
        self.alpha = 0;
        [self layoutIfNeeded];
    }completion:^(BOOL finished) {
        [self removeFromSuperview];
    }];
}
@end
