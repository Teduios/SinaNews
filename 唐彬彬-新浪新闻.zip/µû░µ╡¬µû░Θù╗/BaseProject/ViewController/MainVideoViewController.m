//
//  MainVideoViewController.m
//  BaseProject
//
//  Created by tangbinbin on 15/11/6.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "MainVideoViewController.h"
#import "ScrollDisplayViewController.h"
#import "VideoViewController.h"
@interface MainVideoViewController ()<ScrollDisplayViewControllerDelegate>
@property(nonatomic,strong)ScrollDisplayViewController *sdVcV;
@property(nonatomic,strong)UIScrollView *scrollViewV;
@property(nonatomic,strong)NSMutableArray *btnV;
@property(nonatomic,strong)UIView *lineViewV;
@property(nonatomic,strong)UIButton *currentBtnV;
@end

@implementation MainVideoViewController
-(void)scrollDisplayViewController:(ScrollDisplayViewController *)scrollDisplayViewController currentIndex:(NSInteger)index{
    _currentBtnV.selected = NO;
    _currentBtnV = _btnV[index];
    _currentBtnV.selected = YES;
    [self.lineViewV mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.width.mas_equalTo(45);
        make.height.mas_equalTo(2);
        make.centerX.mas_equalTo(_currentBtnV);
        make.top.mas_equalTo(_currentBtnV.mas_bottom).mas_equalTo(8);
    }];
}
//btns
-(NSMutableArray *)btnV{
    if (!_btnV) {
        _btnV = [NSMutableArray new];
    }
    return _btnV;
}
-(UIView *)lineViewV{
    if (!_lineViewV) {
        _lineViewV = [UIView new];
        _lineViewV.backgroundColor = kRGBColor(234, 25, 23);
    }
    return _lineViewV;
}
-(UIScrollView *)scrollViewV{
    if (!_lineViewV) {
        _scrollViewV = [UIScrollView new];
        NSArray *arr = @[@"笑cry",@"震惊",@"暧心",@"八卦"];
        UIView *lastView = nil;
        for (int i = 0; i<arr.count; i++) {
            UIButton *btn = [UIButton buttonWithType:0];
            [btn setTitle:arr[i] forState:0];
            [btn setTitleColor:kRGBColor(14, 16, 14) forState:UIControlStateNormal];
            [btn setTitleColor:self.lineViewV.backgroundColor forState:UIControlStateSelected];
            if (i == 0) {
                _currentBtnV = btn;
                btn.selected = YES;
        }
            [btn bk_addEventHandler:^(UIButton *sender) {
                //如果当前是点击状态，什么都不做
                //否则取消之前按钮的点击状态，并把当前按钮设置为点击状态
                if (_currentBtnV != sender) {
                    _currentBtnV.selected = NO;
                    sender.selected = YES;
                    _currentBtnV = sender;
                    [self.lineViewV mas_remakeConstraints:^(MASConstraintMaker *make) {
                        make.width.mas_equalTo(40);
                        make.height.mas_equalTo(2);
                        make.centerX.mas_equalTo(sender);
                        make.top.mas_equalTo(sender.mas_bottom).mas_equalTo(8);
                        
                    }];
                    _sdVcV.currentPage=[_btnV indexOfObject:sender];
                }
            } forControlEvents:UIControlEventTouchUpInside];
            [_scrollViewV addSubview:btn];
            [btn mas_makeConstraints:^(MASConstraintMaker *make) {
                make.size.mas_equalTo(CGSizeMake(45, 24));
                make.centerY.mas_equalTo(_scrollViewV);
                if (lastView) {//表示已经添加过按钮
                    make.left.mas_equalTo(lastView.mas_right).mas_equalTo(20);
                    
                }else{
                    make.left.mas_equalTo(40);
                }
                
            }];
            lastView = btn;
            [self.btnV addObject:btn];
        }
        //lastView肯定是最后一个按钮，最后一个按钮的x轴 肯定是固定的，当我们设置按钮的右边缘距离父视图ContentView的右边缘距离10像素
        //那么滚动视图的内容区域就会被锁定了
        [lastView mas_updateConstraints:^(MASConstraintMaker *make) {
            make.right.mas_equalTo(_scrollViewV.mas_right).mas_equalTo(-10);
            }];
        _scrollViewV.showsHorizontalScrollIndicator = NO;
        [_scrollViewV addSubview:self.lineViewV];
        [self.lineViewV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.width.mas_equalTo(40);
            make.height.mas_equalTo(2);
            UIButton *btn = _btnV[0];
            make.centerX.mas_equalTo(btn);
            make.top.mas_equalTo(btn.mas_bottom).mas_equalTo(8);
        }];
        
   
    }
        return _scrollViewV;
    
    }
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    self.scrollViewV.hidden = NO;
}
- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    self.scrollViewV.hidden = YES;
}
-(VideoViewController *)VideoVCWithType:(VideosListType)type{
    VideoViewController *vc = [kStoryboard(@"Main") instantiateViewControllerWithIdentifier:@"VideoViewController"];
    vc.typeV = type;
    return vc;
}
-(ScrollDisplayViewController *)sdVcV{
    if (!_sdVcV) {

        NSArray *vcsV = @[
                         [self VideoVCWithType:VideosListTypeVideo_video],
                         [self VideoVCWithType:VideosListTypeVideo_highlights],
                         [self VideoVCWithType:VideosListTypeVideo_scene],
                         [self VideoVCWithType:VideosListTypeVideo_funny],
                         ];
        _sdVcV = [[ScrollDisplayViewController alloc]initWithControllers:vcsV ];
        _sdVcV.autoCycle = NO;
        _sdVcV.showPageControl = NO;
        _sdVcV.delegate = self;
    }
    return _sdVcV;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self addChildViewController:self.sdVcV];
    [self.view addSubview:self.sdVcV.view];
    [self.sdVcV.view mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(self.view);
    }];
    [self.navigationController.navigationBar addSubview:self.scrollViewV];
    [self.scrollViewV mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.left.right.mas_equalTo(0);
        make.height.mas_equalTo(44);
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
