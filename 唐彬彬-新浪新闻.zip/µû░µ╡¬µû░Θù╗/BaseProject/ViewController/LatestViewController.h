//
//  LatestViewController.h
//  BaseProject
//
//  Created by apple-jd18 on 15/11/2.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "latestViewModel.h"
@interface LatestViewController : UIViewController
@property(nonatomic)NewsListType type;
@end
