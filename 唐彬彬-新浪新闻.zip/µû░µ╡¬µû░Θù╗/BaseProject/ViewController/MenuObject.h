//
//  MenuObject.h
//  新浪新闻
//
//  Created by apple-jd18 on 15/11/30.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MenuObject : NSObject
@property(nonatomic,strong)NSString *menuNmae;

@end
