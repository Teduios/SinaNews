//
//  VideoViewController.m
//  BaseProject
//
//  Created by tangbinbin on 15/11/5.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "VideoViewController.h"
#import "VideoLatestCell.h"
#import "VideoViewmodel.h"
#import "LatestCell.h"
#import "ScrollDisplayViewController.h"
@interface VideoViewController ()<UITableViewDataSource,UITableViewDelegate>
@property (weak, nonatomic) IBOutlet UITableView *tableViewV;

@property(nonatomic,strong)VideoViewmodel *latestVMV;
@property(nonatomic,strong)ScrollDisplayViewController *sdVCV;
@end

@implementation VideoViewController
-(VideoViewmodel *)latestVMV{
    if (!_latestVMV) {
        _latestVMV = [[VideoViewmodel alloc]initWithVideoListType:_typeV ];
    }
    return _latestVMV;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    //头部刷新
    _tableViewV.header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [self.latestVMV refreshDataCompletionHandle:^(NSError *error) {
            [_tableViewV.header endRefreshing];
            [_tableViewV reloadData];
            if (error) {
            [self showErrorMsg:error.localizedDescription];
            }
        }];
    }];
    _tableViewV.footer = [MJRefreshBackNormalFooter footerWithRefreshingBlock:^{
        [self.latestVMV getMoreDataCompletionHandle:^(NSError *error) {
            if (error) {
                [self showErrorMsg:error.description];
            }
            [_tableViewV.footer endRefreshing];
            [_tableViewV reloadData];
        }];
    }];
    //[_tableViewV.header becomeFirstResponder];
    [_tableViewV.header beginRefreshing];
}


#pragma mark - UITableView 注意是Group形式,以section区分
//设置section头部高度1像素， 高度最小是1
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 1;
}
//设置secion脚部高度9像素
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 9;
}
//-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
//    return self.latestVMV.rowNumberV;
//
//}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return self.latestVMV.rowNumberV;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 1;
}




-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    VideoLatestCell *cell = [tableView dequeueReusableCellWithIdentifier:@"VCell"];
    cell.longTitle.text = [self.latestVMV longTitleForRow:indexPath.section];
    cell.playNumber.text = [self.latestVMV PlayCommentForRow:indexPath.section];
    [cell.VideoBtn setBackgroundImageForState:0 withURL:[self.latestVMV videoURLImageForRow:indexPath.section]];
   
    cell.videoUrlV = [self.latestVMV videoURLForRow:indexPath.section];

    return cell;
}
kRemoveCellSeparator
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 258;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
