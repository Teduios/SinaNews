//
//  MenuObject.m
//  新浪新闻
//
//  Created by apple-jd18 on 15/11/30.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "MenuObject.h"

@implementation MenuObject
-(NSString *)menuDescription{
    return [NSString stringWithFormat:@"%@",self.menuNmae];
}
@end
