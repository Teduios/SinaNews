//
//  PicHtmlViewController.m
//  BaseProject
//
//  Created by apple-jd18 on 15/11/9.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "PicHtmlViewController.h"
#import "Factory.h"
@interface PicHtmlViewController ()<UIWebViewDelegate>
@property(nonatomic,strong)UIWebView *WebView;

@end

@implementation PicHtmlViewController
-(id)initWithURL:(NSURL *)url{
    if (self = [super init]) {
        self.url = url;
    }
    return self;
}
-(UIWebView *)WebView{
    if (!_WebView) {
        _WebView = [UIWebView new];
        [_WebView loadRequest:[NSURLRequest requestWithURL:_url]];
        _WebView.delegate = self;
    }
    return _WebView;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    [self.view addSubview:self.WebView];
    [self.WebView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(0);
    }];
    [Factory addBackItemToVC:self];
}
#pragma mark - UIWebViewDelegate

-(void)webViewDidStartLoad:(UIWebView *)webView{
    [self showProgress];
}
-(void)webViewDidFinishLoad:(UIWebView *)webView{
    [self hideProgress];
}
-(void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error{
    [self hideProgress];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];

}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
