//
//  MoreViewController.m
//  新浪新闻
//
//  Created by apple-jd18 on 15/11/27.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "MoreViewController.h"
#import "WitherViewModel.h"
#import "WeahterCell.h"
@interface MoreViewController ()
@property(nonatomic,strong)WitherViewModel *WVC;
@end

@implementation MoreViewController
-(WitherViewModel *)WVC{


     _cityName = self.goPickerBu.titleLabel.text;
    if (!_WVC) {
    
        _WVC = [[WitherViewModel alloc]initWithWitherViewNewsCityName:_cityName];
    }

    return _WVC;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    [Factory addMenuItemToVC:self];
//    self.tableView.header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
//        [self.WVC getDataFromNetCompleteHandle:^(NSError *error) {
//            [self.tableView.header endRefreshing];
//            [self.tableView reloadData];
//            if (error) {
//                [self showErrorMsg:error.localizedDescription];
//            }
//
//        }];
//    }];
//
//    [self.tableView.header beginRefreshing];
    [self reloadDataWeather];
    
}
-(void)reloadDataWeather{
    self.tableView.header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [self.WVC getDataFromNetCompleteHandle:^(NSError *error) {
            [self.tableView.header endRefreshing];
            [self.tableView reloadData];
            if (error) {
                [self showErrorMsg:error.localizedDescription];
            }
            
        }];
    }];
    
    [self.tableView.header beginRefreshing];
}

- (IBAction)goPicker:(id)sender {
    _WVC = nil;
    AddressChoicePickerView *addressPickerView = [[AddressChoicePickerView alloc]init];
    addressPickerView.block = ^(AddressChoicePickerView *view,UIButton *btn,AreaObject *locate){
        [self.goPickerBu setTitle:[NSString stringWithFormat:@"%@",locate] forState:UIControlStateNormal];
        _cityName = [NSString stringWithFormat:@"%@",locate];
        [self reloadDataWeather];
        NSLog(@"%@",[NSString stringWithFormat:@"%@",locate]);
    };
    [addressPickerView show];
    
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
//判断图标
//-()


#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {

    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

    return self.WVC.rowNumberF;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    WeahterCell *cell = [tableView dequeueReusableCellWithIdentifier:@"WCell"];
//    cell.FtemperatureLB.text = [self.WVC futureTemperatureForRow:indexPath.row];
    
    _dateYLB.text = [self.WVC todayDateY];//
    _skTimeLb.text = [self.WVC skTime];//
    _skTemperatureLb.text = [self.WVC skTemp];
    _todayTemperatureLb.text = [self.WVC todayTemperature];//
    _todayWindLb.text = [self.WVC todayWind];//
    _todaydressing_advicelb.text = [self.WVC todayDressingAdvice];//
    _faLb.text = [self.WVC todayWeather];
//    [cellV.ivtit.imageView setImage:[UIImage imageNamed:@"feed_cell_video_mark"]];
//        [cell.CellCimageViewA setImageWithURL:[self.latestVM sizeImageAForRow:indexPath.row+5]];
//    [self.todayImage setImage:[UIImage imageNamed:@"%@"]];
//    NSString *str = [self.WVC todayFa];
     NSString *imageName = [NSString stringWithFormat:@"%@",[self.WVC todayFa]];
    [self.todayImage setImage:[UIImage imageNamed:imageName]];


    
    
    cell.tempLB.text = [_WVC futureTemperatureForRow:indexPath.row];
    cell.FwindLB.text = [self.WVC futureWindForRow:indexPath.row];
    cell.FWeekLb.text = [self.WVC futureWeekForRow:indexPath.row];
    cell.FtemperatureLB.text = [self.WVC faWeatherForRow:indexPath.row];
    NSString *imageName2Cell = [NSString stringWithFormat:@"%@",[self.WVC futureFaForRow:indexPath.row]];
    [cell.FImage setImage:[UIImage imageNamed:imageName2Cell]];
    return cell;
}




/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
