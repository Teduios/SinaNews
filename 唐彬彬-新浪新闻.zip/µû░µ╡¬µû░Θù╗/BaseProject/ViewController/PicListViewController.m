//
//  PicListViewController.m
//  BaseProject
//
//  Created by tangbinbin on 15/11/11.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "PicListViewController.h"
#import "PicCell.h"
#import "PicCellA.h"
#import "PicCellB.h"
#import "PicCellC.h"
#import "PicCellD.h"
#import "PicViewmodel.h"
#import "PicHtmlViewController.h"
@interface PicListViewController ()
@property(nonatomic,strong)PicViewmodel *picVm;
@end

@implementation PicListViewController


-(PicViewmodel *)picVm{
    if (!_picVm) {
        _picVm = [[PicViewmodel alloc]initWithPicListTypeP:_typeP ];
        
    }
    return _picVm;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    [self.tableView registerClass:[PicCell class] forCellReuseIdentifier:@"PCell"];
    [self.tableView registerClass:[PicCellA class] forCellReuseIdentifier:@"PCellA"];
    [self.tableView registerClass:[PicCellB class] forCellReuseIdentifier:@"PCellB"];
    [self.tableView registerClass:[PicCellC class] forCellReuseIdentifier:@"PCellC"];
    [self.tableView registerClass:[PicCellD class] forCellReuseIdentifier:@"PCellD"];
    
    
    
    //    头部刷新
    self.tableView.header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [self.picVm refreshDataCompletionHandle:^(NSError *error) {
            [self.tableView.header endRefreshing];
            [self.tableView reloadData];
            if (error) {
                [self showErrorMsg:error.localizedDescription];
            }
            
        }];
    }];
    self.tableView.footer=[MJRefreshBackNormalFooter footerWithRefreshingBlock:^{
        [self.picVm getMoreDataCompletionHandle:^(NSError *error) {
            if (error) {
                [self showErrorMsg:error.description];
            }
            [self.tableView.footer endRefreshing];
            [self.tableView reloadData];
        }];
    }];
    [self.tableView.header becomeFirstResponder];
    [self.tableView.header beginRefreshing];

}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {

    
    return self.picVm.rowNumberP;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

    return 1;
}


//设置section头部高度1像素， 高度最小是1
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 1;
}
//设置secion脚部高度9像素
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 9;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
//    UITableVCell *cell = [tableView dequeueReusableCellWithIdentifier:<#@"reuseIdentifier"#> forIndexPath:indexPath];
    if (![self.picVm picTemplateForRow:indexPath.section]) {
        PicCell *cell = [tableView dequeueReusableCellWithIdentifier:@"PCell"];
        cell.titleLb.text = [self.picVm titleForRow:indexPath.section];
        cell.introLb.text = [self.picVm introForRow:indexPath.section];
        cell.commentLb.text = [self.picVm commentNumForRow:indexPath.section];
//        [cell.CellAimageView setImageWithURL:[self.latestVM iconURLForRow:indexPath.row]];
        [cell.iconIVP.imageView setImageWithURL:[self.picVm iconURLForRow:indexPath.section] placeholderImage:[UIImage imageNamed:@"angle-mask"]];
        
        return cell;
    }else if ([self.picVm picTemplateForRow:indexPath.section] == 1){
        PicCellA *cell = [tableView dequeueReusableCellWithIdentifier:@"PCellA"];
        cell.titleLbA.text = [self.picVm titleForRow:indexPath.section];
        cell.introLbA.text = [self.picVm introForRow:indexPath.section];
        cell.commentLbA.text = [self.picVm commentNumForRow:indexPath.section];
//        [cell.iconIV2.imageView setImageWithURL:[self.tuwanVM iconURLSForRowInList:indexPath.row][2] placeholderImage:[UIImage imageNamed:@"cell_bg_noData_1"]];
        [cell.iconIVA1.imageView setImageWithURL:[self.picVm iconURLAForRow:indexPath.section]];
        [cell.iconIVA2.imageView setImageWithURL:[self.picVm iconURLBForRow:indexPath.section]];
        return cell;
    }else if([self.picVm picTemplateForRow:indexPath.section] == 2){
        PicCellB *cell = [tableView dequeueReusableCellWithIdentifier:@"PCellB"];
        cell.titleLbB.text = [self.picVm titleForRow:indexPath.section];
        cell.introLbB.text = [self.picVm introForRow:indexPath.section];
        cell.commentLbB.text = [self.picVm commentNumForRow:indexPath.section];
        
        [cell.iconIVB1.imageView setImageWithURL:[self.picVm iconURLAForRow:indexPath.section]];
        [cell.iconIVB2.imageView setImageWithURL:[self.picVm iconURLBForRow:indexPath.section]];
        [cell.iconIVB3.imageView setImageWithURL:[self.picVm iconURLCForRow:indexPath.section]];
        return cell;
    }else if([self.picVm picTemplateForRow:indexPath.section]==3){
        PicCellC *cell = [tableView dequeueReusableCellWithIdentifier:@"PCellC"];
        cell.titleLbC.text = [self.picVm titleForRow:indexPath.section];
        cell.introLbC.text = [self.picVm introForRow:indexPath.section];
        cell.commentLbC.text = [self.picVm commentNumForRow:indexPath.section];
        
        [cell.iconIVC1.imageView setImageWithURL:[self.picVm iconURLAForRow:indexPath.section]];
        [cell.iconIVC2.imageView setImageWithURL:[self.picVm iconURLBForRow:indexPath.section]];
        [cell.iconIVC3.imageView setImageWithURL:[self.picVm iconURLCForRow:indexPath.section]];
        return cell;
    }else{
        PicCellD *cell = [tableView dequeueReusableCellWithIdentifier:@"PCellD"];
        
        cell.titleLbD.text = [self.picVm titleForRow:indexPath.section];
        cell.introLbD.text = [self.picVm introForRow:indexPath.section];
        cell.commentLbD.text = [self.picVm commentNumForRow:indexPath.section];
        
        [cell.iconIVD1.imageView setImageWithURL:[self.picVm iconURLAForRow:indexPath.section]];
        [cell.iconIVD2.imageView setImageWithURL:[self.picVm iconURLBForRow:indexPath.section]];
        [cell.iconIVD3.imageView setImageWithURL:[self.picVm iconURLCForRow:indexPath.section]];
        [cell.iconIVD4.imageView setImageWithURL:[self.picVm iconURLDForRow:indexPath.section]];
        return cell;
    }

}

kRemoveCellSeparator
-(void)tableView:(UITableView *)tableview didSelectRowAtIndexPath:(nonnull NSIndexPath *)indexPath{
    [tableview deselectRowAtIndexPath:indexPath animated:YES];
    if ([self.picVm hltmURLForRow:indexPath.section]) {
        PicHtmlViewController *vc = [[PicHtmlViewController alloc]initWithURL:[self.picVm hltmURLForRow:indexPath.section]];
        [self.navigationController pushViewController:vc animated:YES];
    }
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 280;
}
/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
