//
//  LatestViewController.m
//  BaseProject
//
//  Created by apple-jd18 on 15/11/2.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "LatestViewController.h"
#import "LatestCell.h"
#import "latestViewModel.h"
#import "ScrollDisplayViewController.h"
#import "NewsHaedHtmalViewController.h"
#import "NewsIntoHtmlViewController.h"
#import "TopicViewController.h"
#import "SearchViewController.h"
#import "Factory.h"
//#import "TopicViewController.h"
@interface LatestViewController ()<UITableViewDataSource,UITableViewDelegate,ScrollDisplayViewControllerDelegate>
@property (weak, nonatomic) IBOutlet UITextField *textFile;

@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property(nonatomic,strong)latestViewModel *latestVM;
@property(nonatomic,strong)ScrollDisplayViewController *sdVC;
@end

@implementation LatestViewController
//{//添加成员变量,因为不需要懒加载,所以不需要是属性
//
//    UIPageControl *_pageControl;
//     UILabel *_titleLb;
//}
-(latestViewModel *)latestVM{
    if (!_latestVM) {
        _latestVM = [[latestViewModel alloc] initWithNewsListType:_type];
    }
    return _latestVM;
}

- (void)viewDidLoad {
    
    [super viewDidLoad];
   
//    表格头部
    _tableView.header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [self.latestVM refreshDataCompletionHandle:^(NSError *error) {
            [_tableView.header endRefreshing];
            [_tableView reloadData];
            if (error) {
                [self showErrorMsg:error.localizedDescription];
            }
            [self configTableHeader];
            
        }];
    }];
    _tableView.footer=[MJRefreshBackNormalFooter footerWithRefreshingBlock:^{
        [self.latestVM getMoreDataCompletionHandle:^(NSError *error) {
            if (error) {
                [self showErrorMsg:error.description];
            }
            [_tableView.footer endRefreshing];
            [_tableView reloadData];
        }];
    }];
    [_tableView.header becomeFirstResponder];
    [_tableView.header beginRefreshing];
    DDLogVerbose(@"...");
    
}
-(void)configTableHeader{
    //是否有头部滚动
    if (![self.latestVM isFocusForRow:0]) {
        return;
    }
    
    UIView *headerView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, 0, 185)];
    //把之前的child移除，再新建
    [_sdVC removeFromParentViewController];
    _sdVC = [[ScrollDisplayViewController alloc]initWithImgPaths:self.latestVM.headImageURLs];
    
    //头部标签

    _sdVC.delegate = self;
    [self addChildViewController:_sdVC];
    [headerView addSubview:_sdVC.view];
    [_sdVC.view mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(headerView);
    }];
    _sdVC.autoCycle = NO;
    _tableView.tableHeaderView = headerView;
}

-(void)scrollDisplayViewController:(ScrollDisplayViewController *)scrollDisplayViewController didSelectedIndex:(NSInteger)index{
   [self.textFile resignFirstResponder];

    if ([self.latestVM newsHtmlForRow:index]) {
        NewsHaedHtmalViewController *Vc = [[NewsHaedHtmalViewController alloc]initWithURL:[self.latestVM newsHtmlForRow:index]];
        [self.navigationController pushViewController:Vc animated:Vc];
    }
    
    DDLogVerbose(@"%ld",index);
}

//tableView//
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return self.latestVM.rowNumber-5;
}


-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
  
    if ([self.latestVM videoURLForRow:indexPath.row+5]) {
       
        LatestCell *cell = [tableView dequeueReusableCellWithIdentifier:@"CellD"];
        cell.CellDLongTitle.text = [self.latestVM titleForRow:indexPath.row+5];
        cell.CellDComment.text = [self.latestVM commentNumberForRow:indexPath.row+5];
        [cell.voideBnt setBackgroundImageForState:0 withURL:[self.latestVM iconURLForRow:indexPath.row]];
        cell.videoURL = [self.latestVM videoURLForRow:indexPath.row+5];
        cell.timeLongLB.text = [self.latestVM runTimeForRow:indexPath.row+5];
        return cell;
    }else if ([[self.latestVM bigImgShowForRow:indexPath.row+5] isEqualToString:@"big_img_show"]){
        LatestCell *cell = [tableView dequeueReusableCellWithIdentifier:@"CellB"];
        [cell.CellBimageView  setImageWithURL:[self.latestVM iconURLForRow:indexPath.row+5]];
        cell.CellBLongTitle.text = [self.latestVM titleForRow:indexPath.row+5];
        cell.CellBComment.text = [self.latestVM commentNumberForRow:indexPath.row+5];
        
        return cell;
    }else if ([self.latestVM sizeImageCForRow:indexPath.row+5] && indexPath.row >=0){
        LatestCell *cell = [tableView dequeueReusableCellWithIdentifier:@"CellC"];
        cell.CellCLongTitle.text = [self.latestVM titleForRow:indexPath.row+5];
        cell.CellCComment.text = [self.latestVM commentNumberForRow:indexPath.row+5];
//        cell.nuberImager.text = [self.latestVM totlImageForRow:indexPath.row];

        [cell.CellCimageViewA setImageWithURL:[self.latestVM sizeImageAForRow:indexPath.row+5]];
        [cell.CellCimageViewB setImageWithURL:[self.latestVM sizeImageBForRow:indexPath.row+5]];
        [cell.CellCimageVeiwC setImageWithURL:[self.latestVM sizeImageCForRow:indexPath.row+5]];
        
                return cell;
    }else{
        LatestCell *cell = [tableView dequeueReusableCellWithIdentifier:@"CellA"];
        cell.CellATitle.text = [self.latestVM titleForRow:indexPath.row+5];
        cell.CellAintro.text = [self.latestVM introForRow:indexPath.row+5];
        cell.CellAComment.text = [self.latestVM commentNumberForRow:indexPath.row+5];
        [cell.CellAimageView setImageWithURL:[self.latestVM iconURLForRow:indexPath.row+5]];
        
        return cell;
    }
    }
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if ([self.latestVM videoURLForRow:indexPath.row+5]) {
        return 259;
    }else if ([[self.latestVM bigImgShowForRow:indexPath.row+5] isEqualToString:@"big_img_show"]){
        return 241;
        
    }else if([self.latestVM sizeImageAForRow:indexPath.row+5] && indexPath.row >=0){
        return 135;
    }else{
    return 92;
        }
}
kRemoveCellSeparator
-(void)tableView:(UITableView *)tableview didSelectRowAtIndexPath:(nonnull NSIndexPath *)indexPath{
    [tableview deselectRowAtIndexPath:indexPath animated:YES];
    //收起键盘
    [self.textFile resignFirstResponder];
    if ([[self.latestVM categoryForRow:indexPath.row+5] isEqualToString:@"subject"]) {
        TopicViewController *tvc = [[TopicViewController alloc]initWithID:[self.latestVM IDForRow:indexPath.row+5]];
//        tvc
        [self.navigationController pushViewController:tvc animated:YES];
        
    }else{
        NewsIntoHtmlViewController *vc = [[NewsIntoHtmlViewController alloc]initWithURL:[self.latestVM newsHtmlForRow:indexPath.row+5] ];
        [self.navigationController pushViewController:vc animated:YES];
    }
}

- (IBAction)SeasrchButton:(id)sender {
    [self.textFile resignFirstResponder];
    
    SearchViewController *vc = [self.storyboard instantiateViewControllerWithIdentifier:@"SVC"];
    

    vc.textString = self.textFile.text;
    [self.navigationController pushViewController:vc animated:YES];
}


- (IBAction)closeKeyboard:(id)sender {
    [self.textFile resignFirstResponder];
    
}

-(void)viewDidDisappear:(BOOL)animated{
    [self.view endEditing:YES];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
