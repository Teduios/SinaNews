//
//  PicHtmlViewController.h
//  BaseProject
//
//  Created by apple-jd18 on 15/11/9.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PicHtmlViewController : UIViewController
- (id)initWithURL:(NSURL *)url;
@property(nonatomic,strong) NSURL *url;
@end
