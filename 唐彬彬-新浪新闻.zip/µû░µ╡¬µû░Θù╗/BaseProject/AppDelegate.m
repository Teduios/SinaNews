 //
//  AppDelegate.m
//  BaseProject
//
//  Created by jiyingxin on 15/10/21.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "AppDelegate.h"
#import "AppDelegate+Category.h"
#import "NewsNetManager.h"
#import "NewsModel.h"
#import "VideosNetManager.h"
#import "VideosModel.h"
#import "PicNetManager.h"
#import "PicModel.h"
#import "MainVideoViewController.h"
#import "TopicNetManager.h"
#import "TopicModel.h"
#import "SearchModel.h"
#import "SearchNetManager.h"
#import "MoreViewController.h"
#import "LeftViewController.h"
#import "KTBarController.h"
#import "WeatherNetManager.h"
@interface AppDelegate ()

//@property(nonatomic,strong)WeatherModel *Wdata;
@end

@implementation AppDelegate
//-(WeatherModel *)Wdata{
//    if (!_Wdata) {
//        _Wdata = [WeatherModel new];
//    }
//    return  _Wdata;
//}
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    [self initializeWithApplication:application];
    self.window.rootViewController = self.sideMenu;
    [self configGlobalUIStyle]; //配置全局UI样式
    /*网络请求测试*/
    
//    [NewsNetManager getNewsListType:NewsListTypeNews_toutiao page:1 completionHandle:^(NewsModel *model, NSError *error) {
//        
//        DDLogVerbose(@"");
//    }];

    [NewsNetManager getNewsListType:NewsListTypeNews_toutiao page:2                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             completionHandle:^(NewsModel *model, NSError *error) {
        DDLogVerbose(@"");
    }];
    
    
    [PicNetManager getPicListTypeP:PicListTypeHdpic_story pageP:1 completionHandle:^(PicModel *model, NSError *error) {
        DDLogVerbose(@"...");
    }];
    [VideosNetManager getVideosListTypeV:VideosListTypeVideo_video pageV:1 completionHandle:^(VideosModel *model, NSError *error) {
        DDLogVerbose(@"");  
    }];
    //**测试代码*/
    [TopicNetManager getTopicDataNewsID:@"fxkwaxv2503387-comos-subject" completionHandle:^(TopicModel *model, NSError *error) {
       DDLogVerbose(@"");
    }];
    [WeatherNetManager getWeatherCityNemas:@"苏州" completionHandle:^(WeatherModel *model, NSError *error) {
       
//         self.Wdata = model;
//        DDLogVerbose(@"");
    }];
    return YES;
}


/**配置全局UI的样式*/
-(void)configGlobalUIStyle{
    //**导航栏不透明*/
    [[UINavigationBar appearance]setTranslucent:NO];
    /**设置导航栏背景图*/
    [[UINavigationBar appearance]setBackgroundImage:[UIImage imageNamed:@""] forBarMetrics:UIBarMetricsDefault ];
    //
}
-(UIWindow *)window{
    if (!_window) {
        _window = [[UIWindow alloc]initWithFrame:[UIScreen mainScreen].bounds];
        [_window makeKeyAndVisible];
    }
    return _window;
}
-(RESideMenu *)sideMenu{
    if (!_sideMenu) {
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
//        SearchViewController *vc = [self.storyboard instantiateViewControllerWithIdentifier:@"SVC"];
        _sideMenu = [[RESideMenu alloc]initWithContentViewController:[storyboard instantiateViewControllerWithIdentifier:@"KTB"] leftMenuViewController:[LeftViewController new] rightMenuViewController:nil];
        //为sideMENu设置北景图
        _sideMenu.backgroundImage = [UIImage imageNamed:@"RESideMenu"];
        //可以让出现菜单时不显示状态栏
        _sideMenu.menuPrefersStatusBarHidden = YES;
        //不允许菜单栏到了边缘还可以继续缩小
        _sideMenu.bouncesHorizontally = NO;
//        不显示右边内容
//         _sideMenu.contentViewScaleValue = 0;
    }
    return _sideMenu;
}
@end
