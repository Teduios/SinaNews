//
//  TopicNetManager.m
//  新浪新闻
//
//  Created by apple-jd18 on 15/11/18.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "TopicNetManager.h"

@implementation TopicNetManager

//+(id)getTopicDataNewsListcompletionHandle:(void (^)(TopicModel *, NSError *))completionHandle{
//    NSString *path = [NSString stringWithFormat:@"http://api.sina.cn/sinago/subject.json?id=fxkwaxv2503387-comos-subject&uid=b36916db1fa62eeb&wm=b207&oldchwm=14030_0001&imei=865453023618809&from=6048295012&postt=news_news_toutiao_feed_0&chwm=14030_0001"];
//    return [self GET:path parameters:nil completionHandler:^(id responseObj, NSError *error) {
//        completionHandle([TopicModel objectWithKeyValues:responseObj],error);
//    }];
//}
+(id)getTopicDataNewsID:(NSString *)Id completionHandle:(void (^)(TopicModel *, NSError *))completionHandle{
    NSString *path = [NSString stringWithFormat:@"http://api.sina.cn/sinago/subject.json?id=%@&uid=b36916db1fa62eeb&wm=b207&oldchwm=14030_0001&imei=865453023618809&from=6048295012&postt=news_news_toutiao_feed_0&chwm=14030_0001",Id];
    return [self GET:path parameters:nil completionHandler:^(id responseObj, NSError *error) {
        completionHandle([TopicModel objectWithKeyValues:responseObj],error);
    }];
}




@end
