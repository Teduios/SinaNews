//
//  PicNetManager.h
//  BaseProject
//
//  Created by apple-jd18 on 15/11/7.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseNetManager.h"
#import "PicModel.h"
typedef NS_ENUM(NSUInteger,PicListType){
    PicListTypeHdpic_toutiao,
    PiceosListTypeHdpic_funny,
    PicListTypeHdpic_pretty,
    PicListTypeHdpic_story,
    
};
@interface PicNetManager : BaseNetManager
//通过type来区分 请求的地址
//+ (id)getNewsListType:(PicListType)type lastTitle:(NSString *)title page:(NSInteger)page completionHandle:(void(^)(NewsModel *model, NSError *error))completionHandle;
+(id)getPicListTypeP:(PicListType)typeP pageP:(NSInteger)pageP completionHandle:(void(^)(PicModel *model,NSError *error))completionHandle;
@end
