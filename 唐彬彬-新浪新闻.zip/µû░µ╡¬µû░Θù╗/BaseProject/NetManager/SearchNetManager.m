//
//  SearchNetManager.m
//  新浪新闻
//
//  Created by apple-jd18 on 15/11/23.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "SearchNetManager.h"
//http://op.juhe.cn/onebox/news/query?key=4cb8bfaf96e1bdf204f5c8112766b49a&q=热点新闻
@implementation SearchNetManager
+(id)getSearchNewsKeyWords:(NSString *)keyWords completionHandle:(void(^)(SearchModel *model,NSError *error))completionHandle{
    NSString *path = [NSString stringWithFormat:@"http://op.juhe.cn/onebox/news/query?key=4cb8bfaf96e1bdf204f5c8112766b49a&q=%@",keyWords];
    path = [path stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    return [self GET:path parameters:nil completionHandler:^(id responseObj, NSError *error) {
        completionHandle([SearchModel objectWithKeyValues:responseObj],error);
    }];
}
@end
