//
//  WeatherNetManager.h
//  新浪新闻
//
//  Created by apple-jd18 on 15/11/27.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseNetManager.h"
#import "WeatherModel.h"
@interface WeatherNetManager : BaseNetManager
//http://apis.haoservice.com/weather?cityname=朝阳区&key=5fbdfcd49b3e4078a094e61038ee7270
+(id)getWeatherCityNemas:(NSString *)cityName completionHandle:(void(^)(WeatherModel *model,NSError *error))completionHandle;
@end
