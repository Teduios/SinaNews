//
//  SearchNetManager.h
//  新浪新闻
//
//  Created by apple-jd18 on 15/11/23.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseNetManager.h"
#import "SearchModel.h"
@interface SearchNetManager : BaseNetManager
+(id)getSearchNewsKeyWords:(NSString *)keyWords completionHandle:(void(^)(SearchModel *model,NSError *error))completionHandle;
@end
