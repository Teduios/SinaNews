//
//  TopicNetManager.h
//  新浪新闻
//
//  Created by apple-jd18 on 15/11/18.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseNetManager.h"
#import "TopicModel.h"
@interface TopicNetManager : BaseNetManager
//+(id)getPicListTypeP:(PicListType)typeP pageP:(NSInteger)pageP completionHandle:(void(^)(PicModel *model,NSError *error))completionHandle;
//+(id)getTopicDataNewsListcompletionHandle:(void(^)(TopicModel *model,NSError *error))completionHandle;
+(id)getTopicDataNewsID:(NSString *)Id completionHandle:(void(^)(TopicModel *model,NSError *error))completionHandle;
//+(id)getTcompletionHandle:(void(^)(TopicModel *model,NSError *error))completionHandle;
//+(id)getTopicDataListPagetT:(NSInteger)paget completionHandle:(void(^)(TopicDataNewsListModel *model,NSError *error))completionHandle;
@end
