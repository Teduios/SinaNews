//
//  VideosNetManager.h
//  BaseProject
//
//  Created by tangbinbin on 15/11/5.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseNetManager.h"
#import "VideosModel.h"
typedef NS_ENUM(NSUInteger,VideosListType){
   VideosListTypeVideo_video,
    VideosListTypeVideo_highlights,
    VideosListTypeVideo_scene,
    VideosListTypeVideo_funny,
    
};
@interface VideosNetManager : BaseNetManager
//通过type来区分 请求的地址
//+ (id)getNewsListType:(NewsListType)type lastTitle:(NSString *)title page:(NSInteger)page completionHandle:(void(^)(NewsModel *model, NSError *error))completionHandle;
+(id)getVideosListTypeV:(VideosListType)typeV pageV:(NSInteger)pageV completionHandle:(void(^)(VideosModel *model,NSError *error))completionHandle;
@end
