//
//  WeatherNetManager.m
//  新浪新闻
//
//  Created by apple-jd18 on 15/11/27.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "WeatherNetManager.h"

@implementation WeatherNetManager
+(id)getWeatherCityNemas:(NSString *)cityName completionHandle:(void (^)(WeatherModel *, NSError *))completionHandle{
    //5fbdfcd49b3e4078a094e61038ee7270
    NSString *path = [NSString stringWithFormat:@"http://apis.haoservice.com/weather?cityname=%@&key=5fbdfcd49b3e4078a094e61038ee7270",cityName];
    path = [path stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    return [self GET:path parameters:nil completionHandler:^(id responseObj, NSError *error) {
        completionHandle([WeatherModel objectWithKeyValues:responseObj],error);
    }];
}
@end
