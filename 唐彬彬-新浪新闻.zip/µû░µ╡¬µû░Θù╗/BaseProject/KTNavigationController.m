//
//  KTNavigationController.m
//  新浪新闻
//
//  Created by apple-jd18 on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "KTNavigationController.h"

@interface KTNavigationController ()

@end

@implementation KTNavigationController
+(void)initialize{
    if (self == [KTNavigationController class]) {
        UINavigationBar *bar = [UINavigationBar appearance];
        //2设置导航栏的样式一影响状态中文字的色
//        3.设置标题栏文字的样式
            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
        attributes[NSFontAttributeName] = [UIFont boldSystemFontOfSize:18];
        attributes[NSForegroundColorAttributeName] = kRGBColor(192, 191, 192);
        [bar setTitleTextAttributes:attributes];
        
    }
}
- (void)viewDidLoad {
    [super viewDidLoad];
    UIImage *selectedImage = [self.tabBarItem.selectedImage imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    self.tabBarItem.selectedImage = selectedImage;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
