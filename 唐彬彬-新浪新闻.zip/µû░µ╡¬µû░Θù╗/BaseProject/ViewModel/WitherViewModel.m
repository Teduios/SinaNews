//
//  WitherViewModel.m
//  新浪新闻
//
//  Created by apple-jd18 on 15/11/27.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "WitherViewModel.h"

@implementation WitherViewModel
-(WeatherModel *)Wdata{
    if (!_Wdata) {
        _Wdata = [WeatherModel new];
    }
    return _Wdata;
}
-(NSMutableArray *)dataArrF{
    if (!_dataArrF) {
        _dataArrF = [NSMutableArray new];
    }
    return _dataArrF;
}
-(id)initWithWitherViewNewsCityName:(NSString *)cityName{
    if (self = [super init]) {
        _cityName = cityName;
    }
    return self;
    
}
-(NSInteger)rowNumberF{
    return self.Wdata.result.future.count;
}
-(WeatherResultFutureModel *)WeatherResultForRow:(NSInteger)row{
    return self.Wdata.result.future[row];
}
-(void)getDataCompleteHandle:(void(^)(NSError *))complete{
    [WeatherNetManager getWeatherCityNemas:_cityName completionHandle:^(WeatherModel *model, NSError *error) {
//        self.dataArrF = [model.result mutableCopy];
//        [self.dataArrF addObjectsFromArray:model.result.future];
        self.Wdata = model;
        complete(error);
    }];
}

-(void)getDataFromNetCompleteHandle:(CompletionHandle)completionHandle{
    [self getDataCompleteHandle:completionHandle];
}

//请求是否成功
//-(NSString *)errorCode{
//    return _Wdata.error_code;
//}
-(NSString *)erasonData{
    return self.Wdata.reason;
}
-(NSString *)skTime{
    return self.Wdata.result.sk.time;
}
//当前温度
-(NSString *)skTemp{
    return self.Wdata.result.sk.temp;
}

//更新时间
-(NSString *)todayDateY{
    return self.Wdata.result.today.date_y;
}

-(NSString *)todayWeather{
    return self.Wdata.result.today.weather;
}


//图标判断，天气情况
-(NSString *)todayFa{
    return self.Wdata.result.today.fa;
}
//温度期间
-(NSString *)todayTemperature{
    return self.Wdata.result.today.temperature;
}
-(NSString *)todayWind{
    return self.Wdata.result.today.wind;
}
//旅游指数
-(NSString *)todayTravelIndex{
    return self.Wdata.result.today.travel_index;
}
//晨练指数
-(NSString *)todayExerciseIn{
    return self.Wdata.result.today.exercise_index;
}
//星期
-(NSString *)todayWeek{
    return self.Wdata.result.today.week;
}
//着依意见
-(NSString *)todayDressingAdvice{
    return self.Wdata.result.today.dressing_advice;
}
//预测
//图标及天气情况
-(NSString *)futureFaForRow:(NSInteger)row{
    return self.Wdata.result.future[row].fa;
}
//温度区间
-(NSString *)futureTemperatureForRow:(NSInteger)row{
    return self.Wdata.result.future[row].temperature;
}
//风力
-(NSString *)futureWindForRow:(NSInteger)row{
    return self.Wdata.result.future[row].wind;
}
//星期
-(NSString *)futureWeekForRow:(NSInteger)row{
    return self.Wdata.result.future[row].week;
}
-(NSString *)faWeatherForRow:(NSInteger)row{
    return self.Wdata.result.future[row].weather;
}

@end
