//
//  SearchViewModel.h
//  新浪新闻
//
//  Created by apple-jd18 on 15/11/23.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"
#import "SearchNetManager.h"
@interface SearchViewModel : BaseViewModel
@property(nonatomic,strong)NSMutableArray *dataArrS;
-(id)initWithSearchNewsKeyWords:(NSString *)keyWords;
@property(nonatomic,strong)NSString *keyWords;
//多少行
@property(nonatomic)NSInteger rowNumberS;

-(NSString *)titleForRow:(NSInteger)row;
-(NSString *)pushTimeForRow:(NSInteger)row;
-(NSString *)contentForRow:(NSInteger)row;
-(NSURL *)imageIVForRow:(NSInteger)row;
-(NSURL *)searHtmlForRow:(NSInteger)row;
//用于判断是否有图
-(NSString *)imgForRow:(NSInteger)row;
-(BOOL)imageViewForRow:(NSInteger)row;
@end
