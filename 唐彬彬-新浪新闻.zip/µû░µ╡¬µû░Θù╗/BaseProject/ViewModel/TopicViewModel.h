//
//  TopicViewModel.h
//  新浪新闻
//
//  Created by apple-jd18 on 15/11/19.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"
#import "TopicModel.h"
#import "TopicNetManager.h"

@interface TopicViewModel : BaseViewModel
@property(nonatomic,strong)NSMutableArray *dataArrT;
//@property(nonatomic,strong)NSArray *dataArrT;
//@property(nonatomic,strong)NSMutableArray *dataList;
-(id)initWithID:(NSString *)Id;
@property(nonatomic,strong)NSString *Id;
@property(nonatomic)NSInteger sectionT;

@property(nonatomic)NSInteger rowNumberT;
-(NSInteger)rowNumberT:(NSInteger)section;
//区title
-(NSString *)newsTitleForSection:(NSInteger)section;

-(NSString *)categoryForSection:(NSInteger)section Row:(NSInteger)row;
-(NSString *)titleForSection:(NSInteger)section Row:(NSInteger)row;
-(NSString *)commentForSection:(NSInteger)section Row:(NSInteger)row;
-(NSString *)introForSection:(NSInteger)section Row:(NSInteger)row;
-(NSURL *)kpicForSection:(NSInteger)section Row:(NSInteger)row;
-(NSURL *)picForSection:(NSInteger)section Row:(NSInteger)row;
-(NSURL *)linkForSection:(NSInteger)section Row:(NSInteger)row;

-(BOOL)NoImageForSection:(NSInteger)section Row:(NSInteger)row;
-(BOOL)NoVidoeForSection:(NSInteger)section Row:(NSInteger)row;
//获取分区里的行数
-(NSInteger)sectionForSection :(NSInteger)section;


@end
