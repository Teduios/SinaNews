
//
//  TopicViewModel.m
//  新浪新闻
//
//  Created by apple-jd18 on 15/11/19.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "TopicViewModel.h"

@implementation TopicViewModel
-(id)initWithID:(NSString *)Id{
    if (self = [super init]) {
        _Id = Id;
    }
    return self;
}
-(NSMutableArray *)dataArrT{
    if (!_dataArrT) {
        _dataArrT = [NSMutableArray new];
    }
    return _dataArrT;
}
//多少个分区
-(NSInteger)sectionT{
    return self.dataArrT.count;
}
//分区里有多少行
-(NSInteger)rowNumberT:(NSInteger)section{
//    NSInteger i = [self topicDataNewsForSection:section].list.count;
    return [self topicDataNewsForSection:section].list.count;
//    return 30;

}


-(TopicDataNewsModel *)topicDataNewsForSection:(NSInteger)section{
        return self.dataArrT[section];
}
-(void)getDataCompletHandle:(void(^)(NSError *))complete{
//    [TopicNetManager getTopicDataNewsListcompletionHandle:^(TopicModel *model, NSError *error)
//     {
//         
//
////         self.dataArrT = model.data.news;
//        //[self.dataArrT addObjectsFromArray:model.data.news];
//         self.dataArrT = [model.data.news mutableCopy];
//
//        complete(error);//一定要放到最后
//
//    }];
    [TopicNetManager getTopicDataNewsID:_Id completionHandle:^(TopicModel *model, NSError *error) {
        self.dataArrT = [model.data.news mutableCopy];
        complete(error);//一定要放到最后
    }];
}
//获取数据
- (void)getDataFromNetCompleteHandle:(CompletionHandle)completionHandle{
    [self getDataCompletHandle:completionHandle];
}
//-(void)refreshDataCompletionHandle:(CompletionHandle)completionHandle{
////    _pageT = 0;
//    [self getDataCompletHandle:completionHandle];
//}
//-(void)getMoreDataCompletionHandle:(CompletionHandle)completionHandle{
//    _pageT += 1;
//    [self getDataCompletHandle:completionHandle];
//}

//区title
-(NSString *)newsTitleForSection:(NSInteger)section
{
//   NSString *str = [self topicDataNewsForSection:section].title;
    return [self topicDataNewsForSection:section].title;
}

-(NSString *)categoryForSection:(NSInteger)section Row:(NSInteger)row{
       return [self topicDataNewsForSection:section].list[row].category;
}
-(NSString *)titleForSection:(NSInteger)section Row:(NSInteger)row{
    return [self topicDataNewsForSection:section].list[row].title;
    
}
-(NSString *)commentForSection:(NSInteger)section Row:(NSInteger)row{
    //      return [[self picListmodelForRow:row].comment.stringValue stringByAppendingString:@"评论"];
    return [[self topicDataNewsForSection:section].list[row].comment.stringValue stringByAppendingString:@"评论"];
}
-(NSString *)introForSection:(NSInteger)section Row:(NSInteger)row{


    return [self topicDataNewsForSection:section].list[row].intro;
}
-(NSURL *)kpicForSection:(NSInteger)section Row:(NSInteger)row{
    
    return [NSURL URLWithString:[self topicDataNewsForSection:section].list[row].kpic];
}
-(NSURL *)picForSection:(NSInteger)section Row:(NSInteger)row{
    return [NSURL URLWithString:[self topicDataNewsForSection:section].list[row].pic];
}
-(NSURL *)linkForSection:(NSInteger)section Row:(NSInteger)row
{
    return [NSURL URLWithString:[self topicDataNewsForSection:section].list[row].link];
}
//判断
-(BOOL)NoImageForSection:(NSInteger)section Row:(NSInteger)row{
    return [[self topicDataNewsForSection:section].list[row].kpic isEqualToString:@""];
}

-(BOOL)NoVidoeForSection:(NSInteger)section Row:(NSInteger)row{
    return [[self topicDataNewsForSection:section].list[row].category isEqualToString:@"video"];
}
@end
