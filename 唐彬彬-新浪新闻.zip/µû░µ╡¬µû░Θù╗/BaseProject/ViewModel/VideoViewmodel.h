//
//  VideoViewmodel.h
//  BaseProject
//
//  Created by tangbinbin on 15/11/5.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"
#import "VideosNetManager.h"
@interface VideoViewmodel : BaseViewModel
@property(nonatomic,strong)NSMutableArray *dataArrV;
-(id)initWithVideoListType:(VideosListType)typeV;
@property(nonatomic)VideosListType typeV;
@property(nonatomic)NSInteger pageV;
@property(nonatomic)NSInteger rowNumberV;


- (NSString *)longTitleForRow:(NSInteger)row;
- (NSString *)PlayCommentForRow:(NSInteger)row;
- (NSURL *)videoURLForRow:(NSInteger)row;//视频
- (NSURL *)videoURLImageForRow:(NSInteger)row;


//刷半，加载更多，加载数据在BaseViewModel
@end
