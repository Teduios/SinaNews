//
//  PicViewmodel.h
//  BaseProject
//
//  Created by apple-jd18 on 15/11/7.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"
#import "PicNetManager.h"
#import "PicModel.h"
@interface PicViewmodel : BaseViewModel
@property(nonatomic,strong)NSMutableArray *dataArrP;
-(id)initWithPicListTypeP:(PicListType)typeP;
@property(nonatomic)PicListType typeP;
@property(nonatomic)NSInteger pageP;
@property(nonatomic)NSInteger rowNumberP;

-(NSString *)titleForRow:(NSInteger)row;
-(NSString *)introForRow:(NSInteger)row;
-(NSString *)commentNumForRow:(NSInteger)row;

-(NSURL *)iconURLForRow:(NSInteger)row;
-(NSURL *)iconURLAForRow:(NSInteger)row;
-(NSURL *)iconURLBForRow:(NSInteger)row;
-(NSURL *)iconURLCForRow:(NSInteger)row;
-(NSURL *)iconURLDForRow:(NSInteger)row;

-(NSURL *)hltmURLForRow:(NSInteger)row;
//图片样式
-(NSInteger)picTemplateForRow:(NSInteger)row;
//刷半，加载更多，加载数据在BaseViewModel

@property(nonatomic,strong)PicDataListModel *listModel;
@end
