//
//  VideoViewmodel.m
//  BaseProject
//
//  Created by tangbinbin on 15/11/5.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "VideoViewmodel.h"

@implementation VideoViewmodel
-(id)initWithVideoListType:(VideosListType)type{
    if (self == [super init]) {
        _typeV = type;
    }
    return self;
}
-(NSInteger)rowNumberV{
    return self.dataArrV.count;

}
-(NSMutableArray *)dataArrV{
    if (!_dataArrV) {
        _dataArrV = [NSMutableArray new];
    }
    return _dataArrV;
}
-(VideosDataListModel *)videosListmodelForRow:(NSInteger)row{
    return self.dataArrV[row];
    DDLogVerbose(@"");
}

-(NSString *)longTitleForRow:(NSInteger)row{
//   NSString *title = [self videosListmodelForRow:row].longTitle;
//    return title;
    return [self videosListmodelForRow:row].title;
}
-(NSString *)PlayCommentForRow:(NSInteger)row{

    return [[self videosListmodelForRow:row].videoInfo.playnumber.stringValue stringByAppendingString:@"播放数"];
}
-(NSURL *)videoURLImageForRow:(NSInteger)row{

    return [NSURL URLWithString:[self videosListmodelForRow:row].kpic];
}
-(NSURL *)videoURLForRow:(NSInteger)row{

    return [NSURL URLWithString:[self videosListmodelForRow:row].videoInfo.url];
//    return [NSURL URLWithString:[self videosListmodelForRow:row].link];
}
-(void)getDataCompleteHanle:(void(^)(NSError *))complete{
    [VideosNetManager getVideosListTypeV:_typeV pageV:_pageV completionHandle:^(VideosModel *model, NSError *error) {
        if (_pageV == 1) {
            [self.dataArrV removeAllObjects];
        }
        [self.dataArrV addObjectsFromArray:model.data.list];
        complete(error);
    }];
}
-(void)refreshDataCompletionHandle:(CompletionHandle)completionHandle{
    _pageV = 1;
    [self getDataCompleteHanle:completionHandle];
}
-(void)getMoreDataCompletionHandle:(CompletionHandle)completionHandle{
    _pageV += 1;
    [self getDataCompleteHanle:completionHandle];
}
@end
