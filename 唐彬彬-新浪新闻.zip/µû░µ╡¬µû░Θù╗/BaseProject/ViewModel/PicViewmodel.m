//
//  PicViewmodel.m
//  BaseProject
//
//  Created by apple-jd18 on 15/11/7.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "PicViewmodel.h"

@implementation PicViewmodel
-(id)initWithPicListTypeP:(PicListType)typeP{
    if (self = [super init]) {
        _typeP = typeP;
    }
    return self;
}
-(NSInteger)rowNumberP{
    return self.dataArrP.count;
}
-(NSMutableArray *)dataArrP{
    if (!_dataArrP) {
        _dataArrP = [NSMutableArray new];
    }
    return _dataArrP;
}
-(PicDataListModel *)picListmodelForRow:(NSInteger)row{
    return self.dataArrP[row];
}


-(NSString *)titleForRow:(NSInteger)row{
    
    return [self picListmodelForRow:row].title;
}
-(NSString *)introForRow:(NSInteger)row{
    return [self picListmodelForRow:row].intro;
}


-(NSString *)commentNumForRow:(NSInteger)row{
    return [[self picListmodelForRow:row].comment.stringValue stringByAppendingString:@"评论"];
}
-(NSURL *)hltmURLForRow:(NSInteger)row{
    return [NSURL URLWithString:[self picListmodelForRow:row].link];
}
-(NSURL *)iconURLForRow:(NSInteger)row{
    return [NSURL URLWithString:[self picListmodelForRow:row].pic];
}
-(NSURL *)iconURLAForRow:(NSInteger)row{
//    PicDataListPicsModel *model = self.listModel.pics;
//    return [NSURL URLWithString:[self picListmodelForRow:row].pics.list.pic];
    return [NSURL URLWithString:[self picListmodelForRow:row].pics.list[0].kpic];
}
-(NSURL *)iconURLBForRow:(NSInteger)row{
    return [NSURL URLWithString:[self picListmodelForRow:row].pics.list[1].kpic];
}
-(NSURL *)iconURLCForRow:(NSInteger)row{
    return [NSURL URLWithString:[self picListmodelForRow:row].pics.list[2].kpic];
}
-(NSURL *)iconURLDForRow:(NSInteger)row{
    return [NSURL URLWithString:[self picListmodelForRow:row].pics.list[3].kpic];
}
-(NSInteger)picTemplateForRow:(NSInteger)row{
    return [self picListmodelForRow:row].pics.picTemplate;
}

//
-(void)getdataCompleteHandle:(void(^)(NSError *))complete{
    [PicNetManager getPicListTypeP:_typeP pageP:_pageP completionHandle:^(PicModel *model, NSError *error) {
        if (_pageP == 1) {
            [self.dataArrP removeAllObjects];
        }
        [self.dataArrP addObjectsFromArray:model.data.list];
        complete(error);
    }];
}
-(void)refreshDataCompletionHandle:(CompletionHandle)completionHandle{
    _pageP = 1;
    [self getdataCompleteHandle:completionHandle];
}
-(void)getMoreDataCompletionHandle:(CompletionHandle)completionHandle{
    _pageP += 1;
    [self getdataCompleteHandle:completionHandle];
}
@end
