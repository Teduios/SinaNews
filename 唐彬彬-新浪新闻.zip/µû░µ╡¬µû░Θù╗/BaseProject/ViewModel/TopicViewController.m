//
//  TopicViewController.m
//  新浪新闻
//
//  Created by apple-jd18 on 15/11/22.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "TopicViewController.h"
#import "TopicCell.h"
#import "TopicVCell.h"
#import "TopicHCell.h"
#import "TopicNImageCell.h"
#import "TopicViewModel.h"
#import "TpoicIntorController.h"
#import "Factory.h"
@interface TopicViewController ()
@property(nonatomic,strong)TopicViewModel *topicVM;
@end

@implementation TopicViewController
-(id)initWithID:(NSString *)Id{
    if (self = [super init]) {
        _Id = Id;
    }
    return self;
}
-(TopicViewModel *)topicVM{
    if (!_topicVM) {
        _topicVM = [[TopicViewModel alloc]initWithID:_Id];
    }
    return _topicVM;
}

- (void)viewDidLoad {
    
    
    [super viewDidLoad];
    [self.tableView registerClass:[TopicCell class] forCellReuseIdentifier:@"Cell1"];
    [self.tableView registerClass:[TopicVCell class] forCellReuseIdentifier:@"Cell2V"];
    
    [self.tableView registerClass:[TopicNImageCell class] forCellReuseIdentifier:@"CellN"];
    [self.tableView registerClass:[TopicHCell class] forCellReuseIdentifier:@"CellH"];
    [self.topicVM getDataFromNetCompleteHandle:^(NSError *error) {
        //        [self.tableView.header endRefreshing];
                [self.tableView reloadData];
    }];
    [Factory addBackItemToVC:self];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source
//设置section头部高度1像素， 高度最小是1
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 18;
}
//设置secion脚部高度9像素
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 9;
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    NSLog(@"num section%ld",self.topicVM.sectionT);
    return self.topicVM.sectionT;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    NSLog(@"row %ld",[self.topicVM rowNumberT:section]);
    
    return [self.topicVM rowNumberT:section];
    
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
//    if ([[self.topicVM newsTitleForSection:indexPath.section]isEqualToString:@"title"]) {
//        return 30;
//    }
    return 100;
}
//-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
//    return 20;
//}
//制定个性标题，这里通过UIview来设计标题，功能上丰富，变化多。



- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    //        TopicHCell *cellH = [tableView dequeueReusableCellWithIdentifier:@"CellH"];
      return  [self.topicVM newsTitleForSection:section];


    
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
//    if ([[self.topicVM newsTitleForSection:indexPath.section]isEqualToString:@"title"]) {
//        TopicHCell *cellH = [tableView dequeueReusableCellWithIdentifier:@"CellH"];
//        cellH.headTitleLb.text = [self.topicVM newsTitleForSection:indexPath.section];
//        return cellH;
//    }
//    if (indexPath.row == 0) {
//        return nil;
//    }
//    if ([[self.topicVM categoryForSection:indexPath.section Row:indexPath.row] isEqualToString:@"video"]) {
        if ([self.topicVM NoVidoeForSection:indexPath.section Row:indexPath.row]) {

        TopicVCell *cellV = [tableView dequeueReusableCellWithIdentifier:@"Cell2V"];
        cellV.titleLbV.text = [self.topicVM titleForSection:indexPath.section Row:indexPath.row];
//        NSString *str=[self.topicVM introForSection:indexPath.section Row:indexPath.row];
        cellV.introLbV.text = [self.topicVM introForSection:indexPath.section Row:indexPath.row];
        cellV.commentLbV.text = [self.topicVM commentForSection:indexPath.section Row:indexPath.row];
        [cellV.iconIV.imageView setImageWithURL:[self.topicVM kpicForSection:indexPath.section Row:indexPath.row]];
//        _ivtit.imageView.image = [UIImage imageNamed:@"feed_cell_video_mark"];
        [cellV.ivtit.imageView setImage:[UIImage imageNamed:@"feed_cell_video_mark"]];
        return cellV;
    }else if ([self.topicVM NoImageForSection:indexPath.section Row:indexPath.row]){
        TopicNImageCell *cellN = [tableView dequeueReusableCellWithIdentifier:@"CellN"];
        cellN.titleLbN.text = [self.topicVM titleForSection:indexPath.section Row:indexPath.row];
        cellN.introLbN.text = [self.topicVM introForSection:indexPath.section Row:indexPath.row];
        cellN.commentLbN.text = [self.topicVM commentForSection:indexPath.section Row:indexPath.row];
        
        return cellN;
    }else{
        TopicCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell1"];
        cell.titleLb.text = [self.topicVM titleForSection:indexPath.section Row:indexPath.row];
        cell.commentLb.text = [self.topicVM commentForSection:indexPath.section Row:indexPath.row];

        cell.introLb.text = [self.topicVM introForSection:indexPath.section Row:indexPath.row];

        [cell.iconIVT.imageView setImageWithURL:[self.topicVM kpicForSection:indexPath.section Row:indexPath.row]];
        return cell;
    }

//

    
    
}

kRemoveCellSeparator
-(void)tableView:(UITableView *)tableview didSelectRowAtIndexPath:(nonnull NSIndexPath *)indexPath{
    [tableview deselectRowAtIndexPath:indexPath animated:YES];
//    if ([self.picVm hltmURLForRow:indexPath.section]) {
//        PicHtmlViewController *vc = [[PicHtmlViewController alloc]initWithURL:[self.picVm hltmURLForRow:indexPath.section]];
//        [self.navigationController pushViewController:vc animated:YES];
//    }
    TpoicIntorController *vc = [[TpoicIntorController alloc]initWithURL:[self.topicVM linkForSection:indexPath.section Row:indexPath.row] ];
    [self.navigationController pushViewController:vc animated:YES];
    
}
/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
