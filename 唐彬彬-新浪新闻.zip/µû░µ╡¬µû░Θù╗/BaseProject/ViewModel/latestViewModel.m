//
//  latestViewModel.m
//  BaseProject
//
//  Created by apple-jd18 on 15/10/31.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "latestViewModel.h"

@implementation latestViewModel
//初始化
-(id)initWithNewsListType:(NewsListType)type{
    if (self = [super init]) {
        _type = type;
    }
    return self;
}
//数组长度
-(NSInteger)rowNumber{
    return self.dataArr.count-5;
}



//懒加载
- (NSMutableArray *)dataArr{
    if (!_dataArr) {
        _dataArr=[NSMutableArray new];
    }
    return _dataArr;
}
-(NewsDataListModel *)newsListmodelForRow:(NSInteger)row{
    return self.dataArr[row];
}
-(NSString *)titleForRow:(NSInteger)row{

    return [self newsListmodelForRow:row].title;
}
-(NSString *)longTitleForRow:(NSInteger)row{
    return [self newsListmodelForRow:row].longTitle;
}
-(NSString *)commentNumberForRow:(NSInteger)row{
    return [[self newsListmodelForRow:row].comment.stringValue stringByAppendingString:@"评论"];
}
-(NSString *)totalForRow:(NSInteger)row{
    //    return [[self newsListmodelForRow:row].pics.total.stringValue stringByAppendingString:@"图"];
    //    NSInteger tot = [self newsListmodelForRow:row].pics.total;
    return [[self newsListmodelForRow:row].pics.total.stringValue stringByAppendingString:@"图"];
}

-(NSString *)runTimeForRow:(NSInteger)row{
    NSInteger M =[self newsListmodelForRow:row].videoInfo.runtime/1000;
    return [NSString stringWithFormat:@"%ld秒",M];
}
-(NSString *)HtitleForRow:(NSInteger)row{
    return [self newsListmodelForRow:row-5].title;
}
-(NSString *)categoryForRow:(NSInteger)row{
    return [self newsListmodelForRow:row].category;
}
-(NSString *)IDForRow:(NSInteger)row{
    return [self newsListmodelForRow:row].ID;
}
-(BOOL)isFocusForRow:(NSInteger)row{
    return [self newsListmodelForRow:row].isFocus;
}
-(NSString *)introForRow:(NSInteger)row{
    return [self newsListmodelForRow:row].intro;
}
//大图
-(NSString *)bigImgShowForRow:(NSInteger)row{
    return [self newsListmodelForRow:row].feedShowStyle;
}
//-(NSNumber *)picsForRow:(NSInteger)row{
//    return [self newsListmodelForRow:row].pics.total;
//}
//相片
//头部详情
-(NSURL *)newsHtmlForRow:(NSInteger)row{
    return [NSURL URLWithString:[self newsListmodelForRow:row].link];
}
-(NSURL *)iconURLForRow:(NSInteger)row{
    return [NSURL URLWithString:[self newsListmodelForRow:row].kpic];
}
-(NSURL *)sizeImageAForRow:(NSInteger)row{
    return [NSURL URLWithString:[self newsListmodelForRow:row].pics.list[0].kpic];
}
-(NSURL *)sizeImageBForRow:(NSInteger)row{
    return [NSURL URLWithString:[self newsListmodelForRow:row].pics.list[1].kpic];
}
-(NSURL *)sizeImageCForRow:(NSInteger)row{
    return [NSURL URLWithString:[self newsListmodelForRow:row].pics.list[2].kpic];
}
-(NSURL *)videoURLImageForRow:(NSInteger)row{
    
    return [NSURL URLWithString:[self newsListmodelForRow:row].kpic];
}

- (NSURL *)videoURLForRow:(NSInteger)row{
//    NSString *path=[self newsListmodelForRow:row].videoInfo.url;
    
    return [NSURL URLWithString:[self newsListmodelForRow:row].videoInfo.url];
}

-(void)getDataCompleteHandle:(void(^)(NSError *))complete{
    [NewsNetManager getNewsListType:_type page:_page completionHandle:^(NewsModel *model, NSError *error) {
        if (_page == 1) {
            [self.dataArr removeAllObjects];

        }
        [self.dataArr addObjectsFromArray:model.data.list];
//        NSLog(@"%@",_dataArr);
//        [self.picsArr addObjectsFromArray:model.data.list.];
//        NSLog(@"dataArr%@ ",self.dataArr);
        //[self.latestVM titleForRow:indexPath.row];
        //    if (self.latestVM.headImageURLs.count == 0) {
        //        return;
        //    }
        
        /**判断是否有头视图*/
        if([self isFocusForRow:0]) {
        
        
        NSMutableArray *imgArr = [NSMutableArray new];

        NSInteger i=0;
        for (NewsDataListModel *obj in model.data.list) {
            
            i++;
            if (i<=5) {
            

            NSURL *imageURL = [NSURL URLWithString:obj.kpic];
            [imgArr addObject:imageURL];

            }
        }
//            self.headTitleLb = [tiLB copy];
        self.headImageURLs = [imgArr copy];
        }
        complete(error);
    }];
}

-(void)refreshDataCompletionHandle:(CompletionHandle)completionHandle{
    _page = 1;
    [self getDataCompleteHandle:completionHandle];
}
-(void)getMoreDataCompletionHandle:(CompletionHandle)completionHandle{
    //    NewsDataListModel *obj = self.dataArr.lastObject;
    _page +=1;
//    NSLog(@"%ld",_page);
    [self getDataCompleteHandle:completionHandle];
}

@end
