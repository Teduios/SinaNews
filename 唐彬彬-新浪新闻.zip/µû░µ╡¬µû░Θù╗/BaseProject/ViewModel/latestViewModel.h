//
//  latestViewModel.h
//  BaseProject
//
//  Created by apple-jd18 on 15/10/31.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"
#import "NewsNetManager.h"
@interface latestViewModel : BaseViewModel
@property(nonatomic,strong) NSMutableArray *dataArr;

-(id)initWithNewsListType:(NewsListType)type;
@property(nonatomic)NewsListType type;
@property(nonatomic)NSInteger page;

@property(nonatomic)NSInteger rowNumber;
//@property(nonatomic,strong)NSMutableDictionary *picsDic;

-(NSURL *)iconURLForRow:(NSInteger)row;//pic
-(NSString *)titleForRow:(NSInteger)row;
-(NSString *)commentNumberForRow:(NSInteger)row;
-(NSString *)totlImageForRow:(NSInteger)row;
-(NSString *)introForRow:(NSInteger)row;
-(NSString *)longTitleForRow:(NSInteger)row;
//获取转到Topic
- (NSString *)IDForRow:(NSInteger)row;
- (NSURL *)videoURLForRow:(NSInteger)row;//视频
-(NSURL *)videoURLImageForRow:(NSInteger)row;
-(NSString *)totalForRow:(NSInteger)row;
-(NSString *)runTimeForRow:(NSInteger)row;



//头部详情
-(NSURL *)newsHtmlForRow:(NSInteger)row;
//判断是否有头部
-(BOOL)isFocusForRow:(NSInteger)row;
//-(NSMutableDictionary *)picsForRow:(NSInteger)row;
//头部滚动栏，图片数组
@property(nonatomic,strong)NSArray *headImageURLs;
//头部滚栏标题
//@property(nonatomic,strong)NSArray *headTitleLb;
//刷半，加载更多，加载数据在BaseViewModel

-(NSString *)categoryForRow:(NSInteger)row;

//滚动栏标题
-(NSString *)HtitleForRow:(NSInteger)row;

//大图
-(NSString *)bigImgShowForRow:(NSInteger)row;
//三张图
-(NSURL *)sizeImageAForRow:(NSInteger)row;
-(NSURL *)sizeImageBForRow:(NSInteger)row;
-(NSURL *)sizeImageCForRow:(NSInteger)row;

@end
