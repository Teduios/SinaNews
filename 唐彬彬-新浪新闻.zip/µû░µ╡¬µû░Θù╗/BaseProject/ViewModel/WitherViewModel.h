//
//  WitherViewModel.h
//  新浪新闻
//
//  Created by apple-jd18 on 15/11/27.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"
#import "WeatherNetManager.h"
#import "WeatherModel.h"
@interface WitherViewModel : BaseViewModel
@property(nonatomic,strong)NSMutableArray *dataArrF;
-(id)initWithWitherViewNewsCityName:(NSString *)cityName;
@property(nonatomic,strong)NSString *cityName;
//多少行
@property(nonatomic)NSInteger rowNumberF;
@property(nonatomic,strong)WeatherModel *Wdata;
//请求是否成功
-(NSString *)errorCode;
-(NSString *)erasonData;


//更新时间
-(NSString *)todayDateY;
-(NSString *)skTime;
//当前温度
-(NSString *)skTemp;

//图标判断，天气情况
-(NSString *)todayFa;
//温度期间
-(NSString *)todayTemperature;
-(NSString *)todayWind;
//旅游指数
-(NSString *)todayTravelIndex;
//晨练指数
-(NSString *)todayExerciseIn;
//星期
-(NSString *)todayWeek;
//着依意见
-(NSString *)todayDressingAdvice;
-(NSString *)todayWeather;
-(NSString *)faWeatherForRow:(NSInteger)row;
//预测
//图标及天气情况
-(NSString *)futureFaForRow:(NSInteger)row;
//温度区间
-(NSString *)futureTemperatureForRow:(NSInteger)row;
//风力
-(NSString *)futureWindForRow:(NSInteger)row;
//星期
-(NSString *)futureWeekForRow:(NSInteger)row;
@end
