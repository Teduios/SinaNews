//
//  SearchViewModel.m
//  新浪新闻
//
//  Created by apple-jd18 on 15/11/23.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "SearchViewModel.h"

@implementation SearchViewModel
-(NSMutableArray *)dataArrT{
    if (!_dataArrS) {
        _dataArrS = [NSMutableArray new];
    }
    return _dataArrS;
}
-(id)initWithSearchNewsKeyWords:(NSString *)keyWords{
    if (self = [super init]) {
        _keyWords = keyWords;
    }
    return self;
}
//多少行
-(NSInteger)rowNumberS{
    return self.dataArrS.count;
}
-(SearchResultModel *)SearchResultForRow:(NSInteger)row{
    return self.dataArrS[row];
}
-(void)getDataCompleteHandle:(void(^)(NSError *))complete{
    [SearchNetManager getSearchNewsKeyWords:_keyWords completionHandle:^(SearchModel *model, NSError *error) {
//        [self.dataArrS addObjectsFromArray:model.result];
//        不用刷新只能用复制
        self.dataArrS = [model.result mutableCopy];
        complete(error);
    }];
}
-(void)getDataFromNetCompleteHandle:(CompletionHandle)completionHandle{
    [self getDataCompleteHandle:completionHandle];
}

-(NSString *)titleForRow:(NSInteger)row{
    return [self SearchResultForRow:row].title;
}
-(NSString *)pushTimeForRow:(NSInteger)row{
    return [self SearchResultForRow:row].pdate_src;
}
-(NSString *)contentForRow:(NSInteger)row{
    return [self SearchResultForRow:row].content;
}
-(NSURL *)imageIVForRow:(NSInteger)row{
    return [NSURL URLWithString:[self SearchResultForRow:row].img];
}

-(NSURL *)searHtmlForRow:(NSInteger)row{
    return [NSURL URLWithString:[self SearchResultForRow:row].url];
}
-(NSString *)imgForRow:(NSInteger)row{
    return [self SearchResultForRow:row].url;
}
-(BOOL)imageViewForRow:(NSInteger)row{
    return [[self SearchResultForRow:row].img isEqualToString:@""];
}
@end


