//
//  KTBarController.m
//  新浪新闻
//
//  Created by apple-jd18 on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "KTBarController.h"
#import "KTNavigationController.h"
#import "MainViewController.h"
#import "LatestViewController.h"
#import "PicListViewController.h"
#import "MainVideoViewController.h"
#import "MoreViewController.h"
#import "ViewController.h"
@interface KTBarController ()

@end

@implementation KTBarController
//+(KTBarController *)standarInstance{
//    static KTBarController *vc =nil;
//    static dispatch_once_t onceToken;
//    dispatch_once(&onceToken, ^{
//        vc = [KTBarController new];
//        
//    });
//    return vc;
//}

+(void)initialize{
    if (self == [KTBarController class]) {
        //0获取TabBar的外观
        UITabBar *tabBar = [UITabBar appearance];
        //1.设置背景图
//        [tabBar setBackgroundImage:<#(UIImage * _Nullable)#>];
//        2.设置bar上被选中的项的背景图

//        [tabBar setSelectedImageTintColor:<#(UIColor * _Nullable)#>];
        //获取UITabBarItem的风格
        UITabBarItem *barItem = [UITabBarItem appearance];
        //1.设置item中文字的位置
        [barItem setTitlePositionAdjustment:UIOffsetMake(0, -1)];
        //设置item中的文字的普通样式
        NSMutableDictionary *normalAttrbiutes = [NSMutableDictionary dictionary];
        normalAttrbiutes[NSForegroundColorAttributeName] = kRGBColor(112, 122, 122);
        normalAttrbiutes[NSFontAttributeName] = [UIFont systemFontOfSize:11];
        [barItem setTitleTextAttributes:normalAttrbiutes forState:UIControlStateNormal];
        //3.设置item中选中的样式
        NSMutableDictionary *selectdAttrbiutes = [NSMutableDictionary dictionary];
        selectdAttrbiutes[NSForegroundColorAttributeName] = kRGBColor(240, 76, 84);
        selectdAttrbiutes[NSFontAttributeName] = [UIFont systemFontOfSize:18];
        [barItem setTitleTextAttributes:selectdAttrbiutes forState:UIControlStateSelected];
    }
}
- (void)viewDidLoad {
    [super viewDidLoad];
//    self.tabBar.translucent = NO;
//    [self.navigationController setNavigationBarHidden:YES animated:YES];
////    LatestViewController *vc1 = [[LatestViewController alloc]init];
//    ViewController *vc1 = [ViewController new];
//    PicListViewController *vc2 = [PicListViewController new];
//    MainVideoViewController *vc3 = [[MainVideoViewController alloc]init];
////    MoreViewController *vc4 = [[MoreViewController alloc]init ];
////    MoreViewController *vc4 = [self.storyboard instantiateViewControllerWithIdentifier:@"TZS"];
//    
//    MainViewController *nvc1 = [[MainViewController alloc] initWithRootViewController:vc1];
//        MainViewController *nvc2 = [[MainViewController alloc] initWithRootViewController:vc2];
//        MainViewController *nvc3 = [[MainViewController alloc] initWithRootViewController:vc3];
////        MainViewController *nvc4 = [[MainViewController alloc] initWithRootViewController:vc4];
//    
//    nvc1.tabBarItem = [[UITabBarItem alloc] initWithTitle:@"首页" image:[UIImage imageNamed:@"首页icon"] selectedImage:[UIImage imageNamed:@"首页icon-激活"]];
//    // navc1.tabBarItem.imageInsets = UIEdgeInsetsMake(0, 0, 8, 0);
//    nvc3.tabBarItem = [[UITabBarItem alloc] initWithTitle:@"排行" image:[UIImage imageNamed:@"排行icon"] selectedImage:[UIImage imageNamed:@"排行icon-激活"]];
//    nvc2.tabBarItem = [[UITabBarItem alloc] initWithTitle:@"发现" image:[UIImage imageNamed:@"发现icon"] selectedImage:[UIImage imageNamed:@"发现icon-激活"]];
////    nvc4.tabBarItem = [[UITabBarItem alloc] initWithTitle:@"图说" image:[UIImage imageNamed:@"我的icon"] selectedImage:[UIImage imageNamed:@"我的icon-激活"]];
//    
//    NSArray *controllers = [NSArray arrayWithObjects:nvc1,nvc2,nvc3,nil];
//    self.viewControllers = controllers;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
